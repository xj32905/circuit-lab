package com.lushprojects.circuitjs1.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Vector;

import com.google.gwt.storage.client.Storage;
import com.google.gwt.user.client.Window;
import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Node;
import com.google.gwt.xml.client.XMLParser;
import com.lushprojects.circuitjs1.client.matrix.DMatrixSparseCSC;
import com.lushprojects.circuitjs1.client.matrix.SparseLU;
import com.lushprojects.circuitjs1.client.util.Locale;

public class SimulationManager {

    CirSim app;
    static SimulationManager theSim;

    // this is different than the main elmList; it has CompositeElm child elms in it
    Vector<CircuitElm> elmList;
    
    Vector<CircuitNode> nodeList;
    VoltageSource voltageSources[];

    CircuitMatrix matrices[];
    boolean circuitNonLinear;
    int voltageSourceCount;
    boolean needsStamp;

    // mapping from elements to connected routed wires
    HashMap<CircuitElm, ArrayList<RoutedWireConnection>> routedWireMap;
    CircuitElm elmArr[];
    double t;

    // Solver type: 0=Auto, 1=Dense, 2=Sparse
    static final int SOLVER_AUTO = 0;
    static final int SOLVER_DENSE = 1;
    static final int SOLVER_SPARSE = 2;
    int solverType = SOLVER_AUTO;
    static final int SPARSE_THRESHOLD = 150;
    boolean usingSparse;

    // current timestep (time between iterations)
    double timeStep;

    // maximum timestep (== timeStep unless we reduce it because of trouble
    // converging)
    double maxTimeStep;
    double minTimeStep;

    // accumulated time since we incremented timeStepCount
    double timeStepAccum;

    // incremented each time we advance t by maxTimeStep
    int timeStepCount;

    boolean adjustTimeStep;

    long lastIterTime;
    
    public static native void console(String text) /*-{ console.log(text) }-*/;
    public static native void debugger() /*-{ debugger; }-*/;

    SimulationManager(CirSim app_) {
	theSim = this; app = app_;

	/*
	// load solver preference from localStorage
	try {
	    Storage stor = Storage.getLocalStorageIfSupported();
	    if (stor != null) {
		String s = stor.getItem("solverType");
		if (s != null) solverType = Integer.parseInt(s);
	    }
	} catch (Exception e) {}
	*/
    }
    
    void resetTime() {
    	t = timeStepAccum = 0;
    	timeStepCount = 0;
    }
    
    public CircuitNode getCircuitNode(int n) {
	if (n >= nodeList.size())
	    return null;
	return nodeList.elementAt(n);
    }

    public CircuitElm getElm(int n) {
	if (n >= elmList.size())
	    return null;
	return elmList.elementAt(n);
    }
    
    class NodeMapEntry {
	CircuitNode node;
	NodeMapEntry() { node = null; }
	NodeMapEntry(CircuitNode n) { node = n; }
    }
    // map points to node numbers
    HashMap<Point,NodeMapEntry> nodeMap;
    // separate node map for UI element list (when viewing composite internals)
    HashMap<Point,NodeMapEntry> uiNodeMap;
    
    static class WireSegment {
	CircuitElm wire;
	int bit;
	String endpoint0, endpoint1; // string keys for each endpoint
	Vector<CircuitElm> neighbors; // position-based neighbors
	Vector<WireSegment> labelNeighbors; // neighbors at shared label endpoint
	int post; // 0 or 1: which endpoint was used for current calc
	double current; // set by calcWireCurrents, for label neighbor use

	WireSegment(CircuitElm w, int b, String ep0, String ep1) {
	    wire = w; bit = b; endpoint0 = ep0; endpoint1 = ep1;
	}
    }

    static String pointKey(Point p) { return p.x + "," + p.y + "," + p.z; }

    // info about each wire segment and its neighbors, used to calculate wire currents
    Vector<WireSegment> wireInfoList;
    // the element list that wireInfoList was built from
    HashSet<CircuitElm> wireInfoElmSet;
    // tracks which (element, bit) pairs have been resolved in calcWireInfo
    HashMap<CircuitElm, HashSet<Integer>> wireInfoResolved;
    
    // detect bus widths for wires based on connected elements
    Vector<Point> busMismatchList;

    void detectBusWidths() { detectBusWidths(elmList); }

    void detectBusWidths(Vector<CircuitElm> list) {
	busMismatchList = new Vector<Point>();
	HashMap<Point, Integer> widthMap = new HashMap<Point, Integer>();
	for (int i = 0; i < list.size(); i++) {
	    CircuitElm ce = list.get(i);
	    if (ce.isRemovableWire()) continue;
	    for (int j = 0; j < ce.getPostCount(); j++) {
		int w = ce.getPostWidth(j);
		if (w > 1) {
		    Point pt = ce.getPost(j);
		    Point key = new Point(pt.x, pt.y); // z=0 for map key
		    Integer existing = widthMap.get(key);
		    if (existing != null && existing != w)
			busMismatchList.add(key);
		    if (existing == null || w > existing)
			widthMap.put(key, w);
		}
	    }
	}
	// propagate bus widths through wire chains and matching labels until stable
	HashMap<String, Integer> labelWidthMap = new HashMap<String, Integer>();
	boolean changed = true;
	while (changed) {
	    changed = false;
	    for (int i = 0; i < list.size(); i++) {
		CircuitElm ce = list.get(i);
		if (ce instanceof WireElm) {
		    WireElm wire = (WireElm) ce;
		    Integer w1 = widthMap.get(wire.point1);
		    Integer w2 = widthMap.get(wire.point2);
		    int w = 1;
		    if (w1 != null) w = w1;
		    if (w2 != null && w2 > w) w = w2;
		    if (w != wire.busWidth) {
			wire.busWidth = w;
			wire.currents = (w > 1) ? new double[w] : null;
			wire.allocNodes();
			changed = true;
		    }
		    if (w > 1) {
			if (w1 == null || w1 < w) { widthMap.put(wire.point1, w); changed = true; }
			if (w2 == null || w2 < w) { widthMap.put(wire.point2, w); changed = true; }
		    }
		} else if (ce instanceof LabeledNodeElm) {
		    LabeledNodeElm ln = (LabeledNodeElm) ce;
		    // get max width from position map and label name map
		    Integer w = widthMap.get(ln.point1);
		    Integer lw = labelWidthMap.get(ln.text);
		    int bw = 1;
		    if (w != null) bw = w;
		    if (lw != null && lw > bw) bw = lw;
		    if (bw != ln.busWidth) {
			ln.busWidth = bw;
			ln.currents = (bw > 1) ? new double[bw] : null;
			ln.allocNodes();
			changed = true;
		    }
		    if (bw > 1) {
			if (w == null || w < bw) { widthMap.put(ln.point1, bw); changed = true; }
			if (lw == null || lw < bw) { labelWidthMap.put(ln.text, bw); changed = true; }
		    }
		} else if (ce instanceof BusSplitterElm) {
		    BusSplitterElm bs = (BusSplitterElm) ce;
		    // bus side is at pin 0 position
		    Point p = new Point(bs.pins[0].post.x, bs.pins[0].post.y);
		    int bw = bs.bits;
		    Integer w = widthMap.get(p);
		    if (w != null && w != bw)
			busMismatchList.add(p);
		    if (w == null || w < bw) {
			widthMap.put(p, bw);
			changed = true;
		    }
		}
	    }
	}
	// check for width mismatches: compare each non-wire element's post width
	// against the propagated widthMap.  this catches both direct and wire-mediated mismatches.
	for (int i = 0; i < list.size(); i++) {
	    CircuitElm ce = list.get(i);
	    if (ce.isRemovableWire()) continue;
	    for (int j = 0; j < ce.getPostCount(); j++) {
		int w = ce.getPostWidth(j);
		if (w > 1) {
		    Point pt = ce.getPost(j);
		    Point key = new Point(pt.x, pt.y);
		    Integer propagated = widthMap.get(key);
		    if (propagated != null && propagated != w)
			busMismatchList.add(key);
		}
	    }
	}
    }

    // find groups of nodes connected by wire equivalents and map them to the same node.  this speeds things
    // up considerably by reducing the size of the matrix.  We do this for wires, labeled nodes, and ground.
    // The actual node we map to is not assigned yet.  Instead we map to the same NodeMapEntry.
    void calculateWireClosure() {
	LabeledNodeElm.resetNodeList();
	GroundElm.resetNodeList();
	calculateWireClosureForList(elmList, false);
    }

    // run wire closure on a given element list.  if uiList is true, treat LabeledNodeElm.getConnectedPost()
    // as null (since labeled nodes in subcircuits connect to composite terminals, not to each other)
    void calculateWireClosureForList(Vector<CircuitElm> list, boolean uiList) {
	int i;
	HashMap<Point,NodeMapEntry> nm = new HashMap<Point,NodeMapEntry>();
	wireInfoList = new Vector<WireSegment>();
	wireInfoElmSet = new HashSet<CircuitElm>(list);
	for (i = 0; i != list.size(); i++) {
	    CircuitElm ce = list.get(i);
	    if (!ce.isRemovableWire())
		continue;
	    ce.getWireSegments(wireInfoList);

	    // for bus wires/labels, merge each bit's endpoints; for others, just one pair
	    int bw = ce.getBusWidth();
	    for (int j = 0; j < bw; j++) {
		Point p0 = ce.getPost(j);
		NodeMapEntry cn = nm.get(p0);

		// what post are we connected to
		Point p1 = (uiList && ce instanceof LabeledNodeElm) ? null : ce.getConnectedPost(j);
		if (p1 == null) {
		    // no connected post (true for labeled node the first time it's encountered, or ground)
		    if (cn == null) {
			cn = new NodeMapEntry();
			nm.put(p0, cn);
		    }
		    continue;
		}
		NodeMapEntry cn2 = nm.get(p1);
		if (cn != null && cn2 != null) {
		    // merge nodes; go through map and change all keys pointing to cn2 to point to cn
		    for (Map.Entry<Point, NodeMapEntry> entry : nm.entrySet()) {
			if (entry.getValue() == cn2)
			    entry.setValue(cn);
		    }
		} else if (cn != null) {
		    nm.put(p1, cn);
		} else if (cn2 != null) {
		    nm.put(p0, cn2);
		} else {
		    // new entry
		    cn = new NodeMapEntry();
		    nm.put(p0, cn);
		    nm.put(p1, cn);
		}
	    }
	}
	if (uiList)
	    uiNodeMap = nm;
	else
	    nodeMap = nm;
    }

    // assign nodes to UI wires (which aren't part of simulation) based on neighboring non-wire elements
    // that already have nodes assigned by makeNodeList.  also add wire links to nodeList so calcWireInfo works.
    void assignUiWireNodes() {
	Vector<CircuitElm> uiList = app.ui.elmList;

	// build point-to-node map from non-wire elements in UI list,
	// and add their links to nodeList so calcWireInfo can find neighbors
	// and so setNodeVoltages() updates their volts[] for display
	for (int i = 0; i != uiList.size(); i++) {
	    CircuitElm ce = uiList.get(i);
	    if (ce.isRemovableWire())
		continue;
	    for (int j = 0; j != ce.getPostCount(); j++) {
		Point pt = ce.getPost(j);
		NodeMapEntry nme = uiNodeMap.get(pt);
		CircuitNode cn = ce.getNode(j);
		if (nme != null && nme.node == null && cn != null)
		    nme.node = cn;
		// always link non-wire elements to nodeList so their volts[]
		// get updated, even if the post isn't at a wire endpoint
		// (e.g. composite elements whose posts connect directly)
		if (cn != null) {
		    CircuitNodeLink cnl = new CircuitNodeLink();
		    cnl.num = j;
		    cnl.elm = ce;
		    cn.links.addElement(cnl);
		}
	    }
	}

	// assign nodes to wires and add their links to nodeList
	for (int i = 0; i != uiList.size(); i++) {
	    CircuitElm ce = uiList.get(i);
	    if (!ce.isRemovableWire())
		continue;
	    for (int j = 0; j != ce.getPostCount(); j++) {
		Point pt = ce.getPost(j);
		NodeMapEntry nme = uiNodeMap.get(pt);
		if (nme != null && nme.node != null) {
		    CircuitNode cn = nme.node;
		    ce.setNode(j, cn);
		    CircuitNodeLink cnl = new CircuitNodeLink();
		    cnl.num = j;
		    cnl.elm = ce;
		    cn.links.addElement(cnl);
		} else if (!(ce instanceof LabeledNodeElm))
		    console("missing node for " + pt);
	    }
	}
    }

    // generate info we need to calculate wire currents.  Most other elements calculate currents using
    // the voltage on their terminal nodes.  But wires have the same voltage at both ends, so we need
    // to use the neighbors' currents instead.  We used to treat wires as zero voltage sources to make
    // this easier, but this is very inefficient, since it makes the matrix 2 rows bigger for each wire.
    // We create a list of WireInfo objects instead to help us calculate the wire currents instead,
    // so we make the matrix less complex, and we only calculate the wire currents when we need them
    // (once per frame, not once per subiteration).  We need the WireInfos arranged in the correct order,
    // each one containing a list of neighbors and which end to use (since one end may be ready before
    // the other)
    boolean isWireInfoResolved(CircuitElm ce, int bit) {
	HashSet<Integer> bits = wireInfoResolved.get(ce);
	return bits != null && bits.contains(bit);
    }

    void setWireInfoResolved(CircuitElm ce, int bit) {
	HashSet<Integer> bits = wireInfoResolved.get(ce);
	if (bits == null) {
	    bits = new HashSet<Integer>();
	    wireInfoResolved.put(ce, bits);
	}
	bits.add(bit);
    }

    boolean calcWireInfo() {
	int i, j;
	int moved = 0;
	wireInfoResolved = new HashMap<CircuitElm, HashSet<Integer>>();

	// build label endpoint map: label string → list of WireSegments sharing that label
	HashMap<String, Vector<WireSegment>> labelMap = new HashMap<String, Vector<WireSegment>>();
	for (i = 0; i != wireInfoList.size(); i++) {
	    WireSegment ws = wireInfoList.get(i);
	    if (ws.endpoint1 != null && ws.endpoint1.startsWith("label:")) {
		Vector<WireSegment> list = labelMap.get(ws.endpoint1);
		if (list == null) { list = new Vector<WireSegment>(); labelMap.put(ws.endpoint1, list); }
		list.add(ws);
	    }
	}

	for (i = 0; i != wireInfoList.size(); i++) {
	    WireSegment ws = wireInfoList.get(i);
	    CircuitElm wire = ws.wire;
	    CircuitNode cn1 = wire.getNode(ws.bit);
	    if (cn1 == null) {
		// dangling labeled node not connected to anything inside composite — no current
		ws.neighbors = new Vector<CircuitElm>();
		ws.labelNeighbors = new Vector<WireSegment>();
		setWireInfoResolved(wire, ws.bit);
		continue;
	    }

	    Vector<CircuitElm> neighbors0 = new Vector<CircuitElm>();
	    Vector<CircuitElm> neighbors1 = new Vector<CircuitElm>();
	    Vector<WireSegment> labelNeighbors = new Vector<WireSegment>();
	    boolean isReady0 = true, isReady1 = !(wire instanceof GroundElm);

	    // position-based matching via cn.links
	    for (j = 0; j != cn1.links.size(); j++) {
		CircuitNodeLink cnl = cn1.links.get(j);
		CircuitElm ce = cnl.elm;
		if (ce == wire) continue;
		if (!wireInfoElmSet.contains(ce)) continue;
		if (cnl.num >= ce.getPostCount()) continue;
		Point pt = ce.getPost(cnl.num);
		if (pt == null) continue;
		String ptKey = pointKey(pt);

		int neighborBit = cnl.num % ce.getBusWidth();
		boolean notReady = (ce.isRemovableWire() && !isWireInfoResolved(ce, neighborBit));

		if (ws.endpoint0 != null && ws.endpoint0.equals(ptKey)) {
		    neighbors0.add(ce);
		    if (notReady) isReady0 = false;
		} else if (ws.endpoint1 != null && !ws.endpoint1.startsWith("label:") && ws.endpoint1.equals(ptKey)) {
		    neighbors1.add(ce);
		    if (notReady) isReady1 = false;
		}
	    }

	    // label-based matching: find other WireSegments sharing the same label endpoint
	    if (ws.endpoint1 != null && ws.endpoint1.startsWith("label:")) {
		Vector<WireSegment> peers = labelMap.get(ws.endpoint1);
		if (peers != null) {
		    for (j = 0; j != peers.size(); j++) {
			WireSegment other = peers.get(j);
			if (other == ws) continue;
			boolean notReady = !isWireInfoResolved(other.wire, other.bit);
			labelNeighbors.add(other);
			if (notReady) isReady1 = false;
		    }
		}
	    }

	    if (isReady0) {
		ws.neighbors = neighbors0;
		ws.post = 0;
		setWireInfoResolved(wire, ws.bit);
		moved = 0;
	    } else if (isReady1 && (ws.endpoint1 != null || !(wire instanceof GroundElm))) {
		ws.neighbors = neighbors1;
		ws.labelNeighbors = labelNeighbors;
		ws.post = 1;
		setWireInfoResolved(wire, ws.bit);
		moved = 0;
	    } else {
		wireInfoList.add(wireInfoList.remove(i--));
		moved++;
		if (moved > wireInfoList.size() * 2) {
		    console("wire loop detected, " + wireInfoList.size() + " wires total, unresolved:");
		    for (int k = i; k < wireInfoList.size(); k++) {
			if (k < 0)
			    continue;
			WireSegment wk = wireInfoList.get(k);
			console("  unresolved: " + wk.wire.getClass().getSimpleName()
			    + " bit=" + wk.bit + " ep0=" + wk.endpoint0 + " ep1=" + wk.endpoint1
			    + " resolved=" + wireInfoResolved.get(wk.wire));
		    }
		    stop("wire loop detected", wire);
		    return false;
		}
	    }
	}

	/* for (i = 0; i != wireInfoList.size(); i++) {
	    WireSegment ws = wireInfoList.get(i);
	    console("wireInfo[" + i + "]: " + ws.wire.getClass().getSimpleName()
		+ " bit=" + ws.bit + " post=" + ws.post
		+ " ep0=" + ws.endpoint0 + " ep1=" + ws.endpoint1
		+ " neighbors=" + (ws.neighbors != null ? ws.neighbors.size() : "null")
		+ " labelNeighbors=" + (ws.labelNeighbors != null ? ws.labelNeighbors.size() : "null"));
	} */

	return true;
    }

    // find or allocate ground node
    void setGroundNode(boolean subcircuit) {
	int i;
	boolean gotGround = false;
	boolean gotRail = false;
	CircuitElm volt = null;
	CircuitElm battery = null;

	// allocate ground node
	CircuitNode cn = new CircuitNode();
	cn.index = 0;
	nodeList.addElement(cn);
	CircuitNode.ground = cn;

	//System.out.println("ac1");
	// look for voltage or ground element
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    if (ce instanceof GroundElm) {
		gotGround = true;

		// set ground node
		NodeMapEntry nme = nodeMap.get(ce.getPost(0));
		nme.node = CircuitNode.ground;
		break;
	    }
	    if (ce instanceof RailElm)
	    	gotRail = true;
	    if (volt == null && ce instanceof VoltageElm)
	    	volt = ce;
	    if (battery == null && ce instanceof BatteryElm)
	    	battery = ce;
	}

	// if no ground, and no rails, then the voltage elm's first terminal is ground;
	// if there's no plain voltage elm, fall back to a battery's negative terminal
	// (but not for subcircuits)
	if (!subcircuit && !gotGround && (volt != null || battery != null) && !gotRail) {
	    Point pt = (volt != null ? volt : battery).getPost(0);

	    // update node map
	    NodeMapEntry cln = nodeMap.get(pt);
	    if (cln != null)
		cln.node = CircuitNode.ground;
	    else
		nodeMap.put(pt, new NodeMapEntry(CircuitNode.ground));
	}
    }

    // make list of nodes
    void makeNodeList() {
	int i, j;
	int vscount = 0;

	// call preStamp() on all elements first so CompositeElm can build
	// its internal node list based on final child element state
	for (i = 0; i != elmList.size(); i++)
	    getElm(i).preStamp();

	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    int inodes = ce.getInternalNodeCount();
	    int ivs = ce.getVoltageSourceCount();
	    int posts = ce.getPostCount();
	    
	    // allocate a node for each post and match posts to nodes
	    for (j = 0; j != posts; j++) {
		Point pt = ce.getPost(j);
		NodeMapEntry cln = nodeMap.get(pt);
		
		// is this node not in map yet?  or is the node number unallocated?
		// (we don't allocate nodes before this because changing the allocation order
		// of nodes changes circuit behavior and breaks backward compatibility;
		// the code below to connect unconnected nodes may connect a different node to ground) 
		if (cln == null || cln.node == null) {
		    CircuitNode cn = new CircuitNode();
		    cn.index = nodeList.size();
		    CircuitNodeLink cnl = new CircuitNodeLink();
		    cnl.num = j;
		    cnl.elm = ce;
		    cn.links.addElement(cnl);
		    ce.setNode(j, cn);
		    if (cln != null)
			cln.node = cn;
		    else
			nodeMap.put(pt, new NodeMapEntry(cn));
		    nodeList.addElement(cn);
		} else {
		    CircuitNode cn = cln.node;
		    CircuitNodeLink cnl = new CircuitNodeLink();
		    cnl.num = j;
		    cnl.elm = ce;
		    cn.links.addElement(cnl);
		    ce.setNode(j, cn);
		    // if it's the ground node, make sure the node voltage is 0,
		    // cause it may not get set later
		    if (cn == CircuitNode.ground)
			ce.setNodeVoltage(j, 0);
		}
	    }
	    for (j = 0; j != inodes; j++) {
		CircuitNode cn = new CircuitNode();
		cn.index = nodeList.size();
		cn.internal = true;
		CircuitNodeLink cnl = new CircuitNodeLink();
		cnl.num = j+posts;
		cnl.elm = ce;
		cn.links.addElement(cnl);
		ce.setNode(cnl.num, cn);
		nodeList.addElement(cn);
	    }
	    
	    // also count voltage sources so we can allocate array
	    vscount += ivs;
	}
	
        voltageSources = new VoltageSource[vscount];
    }

    // recursively add child elements to elmList and make node links
    void addChildElms(Vector<CircuitElm> list) {
	for (CircuitElm ce: list) {
	    Vector<CircuitElm> childList = ce.getChildElmList();
	    if (childList != null) {
		// this child is itself a composite; add its children instead
		addChildElms(childList);
		continue;
	    }
	    elmList.add(ce);
	    int nodeCount = ce.getNodeCount();
	    for (int i = 0; i != nodeCount; i++) {
		CircuitNode cn = ce.getNode(i);
		CircuitNodeLink cnl = new CircuitNodeLink();
		cnl.num = i;
		cnl.elm = ce;
		cn.links.addElement(cnl);
		// this is needed so findUnconnectedNodes() works
		cn.internal = false;
		// if it's the ground node, make sure the node voltage is 0
		if (cn.index == 0)
		    ce.setNodeVoltage(i, 0);
	    }
	}
    }

    Vector<Integer> unconnectedNodes;
    Vector<CircuitElm> nodesWithGroundConnection;
    int nodesWithGroundConnectionCount;
    
    void findUnconnectedNodes() {
	int i, j, k;
	int totalNodes = nodeList.size();

	// determine nodes that are not connected indirectly to ground.
	// all nodes must be connected to ground somehow, or else we
	// will get a matrix error.
	boolean closure[] = new boolean[totalNodes];
	unconnectedNodes = new Vector<Integer>();
	nodesWithGroundConnection = new Vector<CircuitElm>();
	closure[0] = true;

	// one pass over elements: seed closure with implicit ground connections
	// and build nodesWithGroundConnection (one entry per element, no duplicates)
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    boolean hasGround = false;
	    for (j = 0; j < ce.getPostCount(); j++) {
		if (ce.hasGroundConnection(j)) {
		    hasGround = true;
		    closure[ce.getNode(j).index] = true;
		}
	    }
	    if (hasGround)
		nodesWithGroundConnection.add(ce);
	}

	// BFS via cn.links: propagate closure through element connections.
	// when the queue drains, scan for an unconnected node and seed it so its
	// whole component is absorbed before we flag the next one.
	// use an index pointer into the vector as a queue to avoid O(n) shifts.
	Vector<Integer> queue = new Vector<Integer>();
	for (i = 0; i < totalNodes; i++)
	    if (closure[i]) queue.add(i);
	int qHead = 0;
	int scanFrom = 1;
	for (;;) {
	    if (qHead < queue.size()) {
		int n = queue.get(qHead++);
		CircuitNode cn = getCircuitNode(n);
		for (j = 0; j != cn.links.size(); j++) {
		    CircuitNodeLink cnl = cn.links.get(j);
		    CircuitElm ce = cnl.elm;
		    int post1 = cnl.num;
		    for (k = 0; k != ce.getPostCount(); k++) {
			if (k == post1)
			    continue;
			int kn = ce.getNode(k).index;
			if (!closure[kn] && ce.getConnection(post1, k)) {
			    closure[kn] = true;
			    queue.add(kn);
			}
		    }
		}
	    } else {
		// queue drained; find next unconnected non-internal node
		boolean found = false;
		for (; scanFrom < totalNodes; scanFrom++) {
		    if (!closure[scanFrom] && !getCircuitNode(scanFrom).internal) {
			unconnectedNodes.add(scanFrom);
			closure[scanFrom] = true;
			queue.add(scanFrom++);
			found = true;
			break;
		    }
		}
		if (!found)
		    break;
	    }
	}
	if (!unconnectedNodes.isEmpty()) {
	    String s = "unconnected nodes:";
	    for (i = 0; i != unconnectedNodes.size(); i++)
		s += " " + unconnectedNodes.get(i);
	    console(s);
	}
    }
    
    void calculateClosures() {
	int totalNodes = nodeList.size();
	int closureIndex[] = new int[totalNodes];
	int i;
	for (i = 1; i != totalNodes; i++)
	    closureIndex[i] = -1;

	int closureCount = 0;
	for (i = 1; i != totalNodes; i++) {
	    if (closureIndex[i] >= 0)
		continue;

	    // flood-fill from node i
	    Vector<Integer> stack = new Vector<Integer>();
	    stack.add(i);
	    closureIndex[i] = closureCount;

	    //console("starting closure " + closureCount + " from node " + i);
	    while (!stack.isEmpty()) {
		int n = stack.remove(stack.size() - 1);
		CircuitNode cn = getCircuitNode(n);
		int j;
		for (j = 0; j != cn.links.size(); j++) {
		    CircuitNodeLink cnl = cn.links.get(j);
		    CircuitElm ce = cnl.elm;
		    int post1 = cnl.num;
		    int k;
		    for (k = 0; k != ce.getNodeCount(); k++) {
			if (k == post1)
			    continue;
			if (!ce.getMatrixConnection(post1, k))
			    continue;
			int kn = ce.getNode(k).index;
			if (kn == 0)
			    continue;  // don't flood through ground
			if (closureIndex[kn] < 0) {
			    //console("  node " + n + " -> node " + kn + " via " + ce.getClass().getSimpleName());
			    closureIndex[kn] = closureCount;
			    stack.add(kn);
			}
		    }
		}
	    }
	    closureCount++;
	}

	// create CircuitMatrix objects, one per closure
	if (closureCount == 0)
	    closureCount = 1;
	matrices = new CircuitMatrix[closureCount];
	for (i = 0; i != closureCount; i++)
	    matrices[i] = new CircuitMatrix();

	// count nodes per closure and assign row numbers
	for (i = 1; i != totalNodes; i++) {
	    int ci = closureIndex[i];
	    if (ci < 0)
		continue;
	    CircuitNode cn = getCircuitNode(i);
	    CircuitMatrix m = matrices[ci];
	    m.nodeCount++;
	    cn.row = m.nodeCount;  // 1-based
	    cn.matrix = m;
	    m.nodeList.add(cn);
	}

	// ground node: row=0, no matrix
	CircuitNode.ground.row = 0;
	CircuitNode.ground.matrix = null;

	for (int ci = 0; ci != closureCount; ci++) {
	    String nodeStr = "";
	    for (i = 1; i != totalNodes; i++) {
		if (closureIndex[i] == ci) {
		    if (nodeStr.length() > 0)
			nodeStr += ", ";
		    nodeStr += i;
		}
	    }
	    //console("matrix " + ci + ": " + matrices[ci].nodeCount + " nodes [" + nodeStr + "]");
	}
    }

    // take list of unconnected nodes, which we identified earlier, and connect them to ground
    // with a big resistor.  otherwise we will get matrix errors.  The resistor has to be big,
    // otherwise circuits like 555 Square Wave will break
    void connectUnconnectedNodes() {
	int i;
	for (i = 0; i != unconnectedNodes.size(); i++) {
	    int n = unconnectedNodes.get(i);
	    stampResistor(CircuitNode.ground, nodeList.get(n), 1e8);
	}
    }
    
    boolean validateCircuit() {
	int i;
	
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    if (!ce.validate())
		return false;
	}
	return true;
    }
    
    // analyze the circuit when something changes, so it can be simulated.
    // Most of this has been moved to preStampCircuit() so it can be avoided if the simulation is stopped.
    void analyzeCircuit() {
	app.setStopElm(null, null);
	elmList = app.elmList;
	if (elmList.isEmpty()) {
	    app.postDrawList = new Vector<Point>();
	    app.badConnectionList = new Vector<Point>();
	    return;
	}
	detectBusWidths();
	if (app.ui.elmList != app.elmList)
	    detectBusWidths(app.ui.elmList);
	makePostDrawList();

	needsStamp = true;
    }

    // do the rest of the pre-stamp circuit analysis
    boolean preStampCircuit(boolean subcircuit) {
	int i, j;
	nodeList = new Vector<CircuitNode>();
	elmList = app.elmList;
	calculateWireClosure();
	setGroundNode(subcircuit);

	// allocate nodes and voltage sources
	makeNodeList();

	// if UI is showing composite internals, run wire closure on UI list to assign
	// nodes to display-only wires and build wireInfoList for current display
	if (app.ui.elmList != app.elmList) {
	    detectBusWidths(app.ui.elmList);
	    calculateWireClosureForList(app.ui.elmList, true);
	    assignUiWireNodes();
	}

	if (!calcWireInfo())
	    return false;

	nodeMap = null; // done with this
	uiNodeMap = null;

	// add composite child elements to elmList and make node links
	elmList = new Vector<>(app.elmList);
	for (CircuitElm elm: elmList) {
	    Vector<CircuitElm> list = elm.getChildElmList();
	    if (list != null)
		addChildElms(list);
	}

	int vscount = 0;
	circuitNonLinear = false;

	// determine if circuit is nonlinear.  also set voltage sources
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    if (ce.nonLinear())
		circuitNonLinear = true;
	    int ivs = ce.getVoltageSourceCount();
	    for (j = 0; j != ivs; j++) {
		VoltageSource vs = new VoltageSource();
		vs.index = vscount;
		vs.elm = ce;
		voltageSources[vscount] = vs;
		ce.setVoltageSource(j, vs);
		vscount++;
	    }
	}
	voltageSourceCount = vscount;

	// show resistance in voltage sources if there's only one.
	// can't use voltageSourceCount here since that counts internal voltage sources, like the one in GroundElm
	boolean gotVoltageSource = false;
	app.showResistanceInVoltageSources = true;
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    if (ce instanceof VoltageElm) {
		if (gotVoltageSource)
		    app.showResistanceInVoltageSources = false;
		else
		    gotVoltageSource = true;
	    }
	}

	findUnconnectedNodes();
	calculateClosures();

	if (!validateCircuit())
	    return false;
	
	// assign voltage sources to matrices
	int vsPerMatrix[] = new int[matrices.length];
	for (i = 0; i != voltageSourceCount; i++) {
	    VoltageSource vs = voltageSources[i];
	    vs.assignMatrix();
	}
	// assign VS row numbers (after node rows)
	for (i = 0; i != voltageSourceCount; i++) {
	    VoltageSource vs = voltageSources[i];
	    CircuitMatrix m = vs.matrix;
	    int mi = 0;
	    for (j = 0; j != matrices.length; j++)
		if (matrices[j] == m) { mi = j; break; }
	    vsPerMatrix[mi]++;
	    vs.row = m.nodeCount + vsPerMatrix[mi];  // 1-based, after node rows
	    m.voltageSourceList.add(vs);
	}
	// set matrix sizes
	for (i = 0; i != matrices.length; i++) {
	    matrices[i].size = matrices[i].nodeCount + vsPerMatrix[i];
	    //console("matrix " + i + ": size=" + matrices[i].size + " nodes=" + matrices[i].nodeCount + " vs=" + vsPerMatrix[i]);
	}

	nodesWithGroundConnectionCount = nodesWithGroundConnection.size();
	// only need this for validation
	nodesWithGroundConnection = null;
	
	timeStep = maxTimeStep;
	needsStamp = true;
	
	app.jsInterface.callAnalyzeHook();
	return true;
    }

    // do pre-stamping and then stamp circuit
    void preStampAndStampCircuit() {
	int i;

	// preStampCircuit returns false if there's an error.  It can return false if we have capacitor loops
	// but we just need to try again in that case.  Try again 10 times to avoid infinite loop.
	for (i = 0; i != 10; i++)
	    if (preStampCircuit(false) || app.stopMessage != null)
		break;
	if (app.stopMessage != null)
	    return;
	if (i == 10) {
	    stop("failed to stamp circuit", null);
	    return;
	}

	stampCircuit();
    }

    // stamp the matrix, meaning populate the matrix as required to simulate the circuit (for all linear elements, at least).
    // this gets called after something changes in the circuit, and also when auto-adjusting timestep
    void stampCircuit() {
	int i;

	// initialize per-matrix arrays
	for (i = 0; i != matrices.length; i++) {
	    CircuitMatrix m = matrices[i];
	    int sz = m.size;
	    m.matrix = new double[sz][sz];
	    m.rightSide = new double[sz];
	    m.origMatrix = new double[sz][sz];
	    m.origRightSide = new double[sz];
	    m.permute = new int[sz];
	    m.nodeVoltages = new double[m.nodeCount];
	    if (m.lastNodeVoltages == null || m.lastNodeVoltages.length != m.nodeCount)
		m.lastNodeVoltages = new double[m.nodeCount];
	    m.nonLinear = false;
	}

	// set nonLinear flag per matrix
	if (circuitNonLinear) {
	    for (i = 0; i != matrices.length; i++)
		matrices[i].nonLinear = true;
	}

	connectUnconnectedNodes();

	// stamp linear circuit elements
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    ce.setParentList(elmList);
	    ce.stamp();
	}

	// check if we called stop()
	if (matrices == null)
	    return;

	// save original matrices for restoring during nonlinear iterations
	int maxMatrixSize = 0;
	for (int mi = 0; mi != matrices.length; mi++) {
	    CircuitMatrix m = matrices[mi];
	    int sz = m.size;
	    if (sz > maxMatrixSize) maxMatrixSize = sz;
	    for (i = 0; i != sz; i++)
		m.origRightSide[i] = m.rightSide[i];
	    for (i = 0; i != sz; i++)
		for (int j = 0; j != sz; j++)
		    m.origMatrix[i][j] = m.matrix[i][j];
	    //CirSim.console("matrix " + mi + " size: " + sz);
	}
	// determine which solver to use (AUTO uses the largest matrix size to decide)
	if (solverType == SOLVER_SPARSE)
	    usingSparse = true;
	else if (solverType == SOLVER_DENSE)
	    usingSparse = false;
	else // SOLVER_AUTO
	    usingSparse = (maxMatrixSize >= SPARSE_THRESHOLD);
	// sparseLU is per-matrix (CircuitMatrix.sparseLU), reset implicitly when matrices[] is recreated

	// if a matrix is linear, we can do the lu_factor here instead of
	// needing to do it every frame
	for (int mi = 0; mi != matrices.length; mi++) {
	    CircuitMatrix m = matrices[mi];
	    if (!m.nonLinear) {
		if (!lu_factor(m.matrix, m.size, m.permute, m)) {
		    stop("Singular matrix!", null);
		    return;
		}
	    }
	}

	// copy elmList to an array to avoid a bunch of calls to canCast() when doing simulation
	elmArr = new CircuitElm[elmList.size()];
	int scopeElmCount = 0;
	for (i = 0; i != elmList.size(); i++) {
	    elmArr[i] = elmList.get(i);
	    if (elmArr[i] instanceof ScopeElm)
		scopeElmCount++;
	}

	// copy ScopeElms to an array to avoid a second pass over entire list of elms during simulation
	ScopeElm scopeElmArr[] = new ScopeElm[scopeElmCount];
	int j = 0;
	for (i = 0; i != elmList.size(); i++) {
	    if (elmArr[i] instanceof ScopeElm)
		scopeElmArr[j++] = (ScopeElm) elmArr[i];
	}
	app.scopeElmArr = scopeElmArr;

	needsStamp = false;
    }

    // make list of posts we need to draw.  posts shared by 2 elements should be hidden, all
    // others should be drawn.  We can't use the node list for this purpose anymore because wires
    // have the same node number at both ends.
    void makePostDrawList() {
        HashMap<Point,Integer> postCountMap = new HashMap<Point,Integer>();
	Vector<CircuitElm> drawList = app.ui.elmList;
	int i, j;
	for (i = 0; i != drawList.size(); i++) {
	    CircuitElm ce = drawList.get(i);
	    int posts = ce.getPostCount();
	    for (j = 0; j != posts; j++) {
		Point pt = ce.getPost(j);
		Integer g = postCountMap.get(pt);
		postCountMap.put(pt, g == null ? 1 : g+1);
	    }
	}

	Vector<Point> postDrawList = app.postDrawList = new Vector<Point>();
	Vector<Point> badConnectionList = app.badConnectionList = new Vector<Point>();
	for (Map.Entry<Point, Integer> entry : postCountMap.entrySet()) {
	    if (entry.getValue() != 2)
		postDrawList.add(entry.getKey());
	    
	    // look for bad connections, posts not connected to other elements which intersect
	    // other elements' bounding boxes
	    if (entry.getValue() == 1) {
		boolean bad = false;
		Point cn = entry.getKey();
		for (j = 0; j != drawList.size() && !bad; j++) {
		    CircuitElm ce = drawList.get(j);
		    if ( ce instanceof GraphicElm )
			continue;

		    // routed wire: check path directly instead of bounding box (which is too big)
		    if (ce instanceof RoutedWireElm) {
			if (((RoutedWireElm) ce).pointOnPath(cn))
			    bad = true;
			continue;
		    }

		    // does this post intersect elm's bounding box?
		    if (!ce.boundingBox.contains(cn.x, cn.y))
			continue;
		    int k;
		    // does this post belong to the elm?
		    int pc = ce.getPostCount();
		    for (k = 0; k != pc; k++)
			if (ce.getPost(k).equals(cn))
			    break;
		    if (k == pc)
			bad = true;
		}
		if (bad)
		    badConnectionList.add(cn);
	    }
	}
	badConnectionList.addAll(busMismatchList);

	// build mapping from elements to connected routed wires
	routedWireMap = new HashMap<CircuitElm, ArrayList<RoutedWireConnection>>();
	for (i = 0; i != drawList.size(); i++) {
	    CircuitElm ce = drawList.get(i);
	    if (!(ce instanceof RoutedWireElm))
		continue;
	    RoutedWireElm rw = (RoutedWireElm) ce;
	    int rwPosts = rw.getPostCount();
	    for (int rp = 0; rp < rwPosts; rp++) {
		Point rwPt = rw.getPost(rp);
		for (j = 0; j != drawList.size(); j++) {
		    CircuitElm other = drawList.get(j);
		    if (other == rw || other instanceof RoutedWireElm)
			continue;
		    int otherPosts = other.getPostCount();
		    for (int op = 0; op < otherPosts; op++) {
			if (other.getPost(op).equals(rwPt)) {
			    ArrayList<RoutedWireConnection> list = routedWireMap.get(other);
			    if (list == null) {
				list = new ArrayList<RoutedWireConnection>();
				routedWireMap.put(other, list);
			    }
			    list.add(new RoutedWireConnection(rw, rp, op));
			}
		    }
		}
	    }
	}
    }


    void stop(String s, CircuitElm ce) {
	app.setStopElm(ce, Locale.LS(s));
	matrices = null;  // causes an exception
	app.setSimRunning(false);
	app.analyzeFlag = false;
    }
    
    // control voltage source vs with voltage from n1 to n2 (must
    // also call stampVoltageSource())
    void stampVCVS(CircuitNode n1, CircuitNode n2, double coef, VoltageSource vs) {
	stampMatrix(vs, n1, coef);
	stampMatrix(vs, n2, -coef);
    }

    // stamp independent voltage source #vs, from n1 to n2, amount v
    void stampVoltageSource(CircuitNode n1, CircuitNode n2, VoltageSource vs, double v) {
	stampMatrix(vs, n1, -1);
	stampMatrix(vs, n2, 1);
	stampRightSide(vs, v);
	stampMatrix(n1, vs, 1);
	stampMatrix(n2, vs, -1);
    }

    // use this if the amount of voltage is going to be updated in doStep(), by updateVoltageSource()
    void stampVoltageSource(CircuitNode n1, CircuitNode n2, VoltageSource vs) {
	stampMatrix(vs, n1, -1);
	stampMatrix(vs, n2, 1);
	stampMatrix(n1, vs, 1);
	stampMatrix(n2, vs, -1);
    }

    // stamp voltage source using nodes saved in VoltageSource
    void stampVoltageSource(VoltageSource vs, double v) {
	stampVoltageSource(vs.n1, vs.n2, vs, v);
    }

    // update voltage source in doStep()
    void updateVoltageSource(CircuitNode n1, CircuitNode n2, VoltageSource vs, double v) {
	stampRightSide(vs, v);
    }

    void stampResistor(CircuitNode n1, CircuitNode n2, double r) {
	double r0 = 1/r;
	if (Double.isNaN(r0) || Double.isInfinite(r0)) {
	    System.out.print("bad resistance " + r + " " + r0 + "\n");
	    int a = 0;
	    a /= a;
	}
	stampMatrix(n1, n1, r0);
	stampMatrix(n2, n2, r0);
	stampMatrix(n1, n2, -r0);
	stampMatrix(n2, n1, -r0);
    }

    void stampConductance(CircuitNode n1, CircuitNode n2, double r0) {
	stampMatrix(n1, n1, r0);
	stampMatrix(n2, n2, r0);
	stampMatrix(n1, n2, -r0);
	stampMatrix(n2, n1, -r0);
    }

    // specify that current from cn1 to cn2 is equal to voltage from vn1 to vn2, divided by g
    void stampVCCurrentSource(CircuitNode cn1, CircuitNode cn2, CircuitNode vn1, CircuitNode vn2, double g) {
	stampMatrix(cn1, vn1, g);
	stampMatrix(cn2, vn2, g);
	stampMatrix(cn1, vn2, -g);
	stampMatrix(cn2, vn1, -g);
    }

    void stampCurrentSource(CircuitNode n1, CircuitNode n2, double i) {
	stampRightSide(n1, -i);
	stampRightSide(n2, i);
    }

    // stamp a current source from n1 to n2 depending on current through vs
    void stampCCCS(CircuitNode n1, CircuitNode n2, VoltageSource vs, double gain) {
	stampMatrix(n1, vs, gain);
	stampMatrix(n2, vs, -gain);
    }

    // stamp value x in row i, column j, meaning that a voltage change
    // of dv in node j will increase the current into node i by x dv.
    // (Unless i or j is a voltage source node.)
    void stampMatrix(CircuitNode i, CircuitNode j, double x) {
	if (Double.isInfinite(x))
	    debugger();
	if (i.row > 0 && j.row > 0) {
	    if (i.matrix != j.matrix)
		console("stampMatrix cross-matrix! node " + i.index + " (matrix row " + i.row + ") vs node " + j.index + " (matrix row " + j.row + ")");
	    CircuitMatrix m = (i != CircuitNode.ground) ? i.matrix : j.matrix;
	    m.matrix[i.row-1][j.row-1] += x;
	}
    }
    void stampMatrix(VoltageSource i, CircuitNode j, double x) {
	if (Double.isInfinite(x))
	    debugger();
	if (j.row > 0) {
	    if (i.matrix != j.matrix)
		console("stampMatrix cross-matrix! vs row " + i.row + " vs node " + j.index + " (row " + j.row + ")");
	    i.matrix.matrix[i.row-1][j.row-1] += x;
	}
    }
    void stampMatrix(CircuitNode i, VoltageSource j, double x) {
	if (Double.isInfinite(x))
	    debugger();
	if (i.row > 0) {
	    if (i.matrix != j.matrix)
		console("stampMatrix cross-matrix! node " + i.index + " (row " + i.row + ") vs vs row " + j.row);
	    j.matrix.matrix[i.row-1][j.row-1] += x;
	}
    }
    void stampMatrix(VoltageSource i, VoltageSource j, double x) {
	if (Double.isInfinite(x))
	    debugger();
	if (i.matrix != j.matrix)
	    console("stampMatrix cross-matrix! vs row " + i.row + " vs vs row " + j.row);
	i.matrix.matrix[i.row-1][j.row-1] += x;
    }

    // stamp value x on the right side of row i, representing an
    // independent current source flowing into node i
    void stampRightSide(CircuitNode n, double x) {
	if (n.row > 0)
	    n.matrix.rightSide[n.row-1] += x;
    }
    void stampRightSide(VoltageSource vs, double x) {
	vs.matrix.rightSide[vs.row-1] += x;
    }

    // indicate that the value on the right side of row changes in doStep() (no-ops)
    void stampRightSide(CircuitNode n) { }
    void stampRightSide(VoltageSource vs) { }

    // indicate that the values on the left side of row change in doStep() (no-ops)
    void stampNonLinear(CircuitNode n) { }
    void stampNonLinear(VoltageSource vs) { }

    boolean converged;
    int subIterations;
    
    void runCircuit(boolean didAnalyze) {
	if (matrices == null || elmList.size() == 0) {
	    matrices = null;
	    return;
	}
	int iter;
	//int maxIter = getIterCount();
	boolean debugprint = app.dumpMatrix;
	app.dumpMatrix = false;
	long steprate = (long) (160*app.getIterCount());
	long tm = System.currentTimeMillis();
	long lit = lastIterTime;
	if (lit == 0) {
	    lastIterTime = tm;
	    return;
	}
	
	// Check if we don't need to run simulation (for very slow simulation speeds).
	// If the circuit changed, do at least one iteration to make sure everything is consistent.
	if (1000 >= steprate*(tm-lastIterTime) && !didAnalyze)
	    return;
	
	boolean delayWireProcessing = app.scopeManager.canDelayWireProcessing();
	
	int timeStepCountAtFrameStart = timeStepCount;
	
	// keep track of iterations completed without convergence issues
	int goodIterations = 100;
	
	int frameTimeLimit = (int) (1000/app.minFrameRate);
	
	for (iter = 1; ; iter++) {
	    if (goodIterations >= 3 && timeStep < maxTimeStep) {
		// things are going well, double the time step
		timeStep = Math.min(timeStep*2, maxTimeStep);
		console("timestep up = " + timeStep + " at " + t);
		stampCircuit();
		goodIterations = 0;
	    }
	    if (TestManager.theManager != null)
		timeStep = TestManager.theManager.clampTimeStep(t, timeStep);

	    int i, j, subiter;
	    for (i = 0; i != elmArr.length; i++)
		elmArr[i].startIteration();
	    app.ui.steps++;
	    int subiterCount = (adjustTimeStep && timeStep/2 > minTimeStep) ? 100 : 5000;
	    for (subiter = 0; subiter != subiterCount; subiter++) {
		converged = true;
		subIterations = subiter;
		for (int mi = 0; mi != matrices.length; mi++) {
		    CircuitMatrix m = matrices[mi];
		    for (i = 0; i != m.size; i++)
			m.rightSide[i] = m.origRightSide[i];
		    if (m.nonLinear) {
			for (i = 0; i != m.size; i++)
			    for (j = 0; j != m.size; j++)
				m.matrix[i][j] = m.origMatrix[i][j];
		    }
		}
		for (i = 0; i != elmArr.length; i++)
		    elmArr[i].doStep();
		if (app.stopMessage != null)
		    return;
		boolean printit = debugprint;
		debugprint = false;
		for (int mi = 0; mi != matrices.length; mi++) {
		    CircuitMatrix m = matrices[mi];
		    if (m.size < 8) {
			for (j = 0; j != m.size; j++) {
			    for (i = 0; i != m.size; i++) {
				double x = m.matrix[i][j];
				if (Double.isNaN(x) || Double.isInfinite(x)) {
				    stop("nan/infinite matrix!", null);
				    console("matrix " + mi + " [" + i + "][" + j + "] is " + x);
				    return;
				}
			    }
			}
		    }
		    if (printit) {
			console("matrix " + mi + ":");
			for (j = 0; j != m.size; j++) {
			    String x = "";
			    for (i = 0; i != m.size; i++)
				x += m.matrix[j][i] + ",";
			    x += "\n";
			    console(x);
			}
		    }
		    if (m.nonLinear) {
			if (converged && subiter > 0)
			    continue;
			if (!lu_factor(m.matrix, m.size, m.permute, m)) {
			    stop("Singular matrix!", null);
			    return;
			}
		    }
		    lu_solve(m.matrix, m.size, m.permute, m.rightSide, m);
		    applySolvedRightSide(m);
		}
		if (printit)
		    console("done");
		if (!circuitNonLinear)
		    break;
		if (converged && subiter > 0)
		    break;
	    }
	    if (subiter == subiterCount) {
		// convergence failed
		goodIterations = 0;
		if (adjustTimeStep) {
		    timeStep /= 2;
		    console("timestep down to " + timeStep + " at " + t);
		}
		if (timeStep < minTimeStep || !adjustTimeStep) {
		    console("convergence failed after " + subiter + " iterations");
		    stop("Convergence failed!", null);
		    break;
		}
		// we reduced the timestep.  reset circuit state to the way it was at start of iteration
		for (int mi = 0; mi != matrices.length; mi++)
		    setNodeVoltages(matrices[mi], matrices[mi].lastNodeVoltages);
		stampCircuit();
		continue;
	    }
	    if (subiter > 5 || timeStep < maxTimeStep)
		console("converged after " + subiter + " iterations, timeStep = " + timeStep);
	    if (subiter < 3)
		goodIterations++;
	    else
		goodIterations = 0;
	    t += timeStep;
	    timeStepAccum += timeStep;
	    if (timeStepAccum >= maxTimeStep) {
		timeStepAccum -= maxTimeStep;
		timeStepCount++;
	    }
	    for (i = 0; i != elmArr.length; i++)
		elmArr[i].stepFinished();
	    if (!delayWireProcessing)
		calcWireCurrents();
	    app.onTimeStep();
	    if (TestManager.theManager != null && TestManager.theManager.checkTime())
		break;
	    // save last node voltages so we can restart the next iteration if necessary
	    for (int mi = 0; mi != matrices.length; mi++) {
		CircuitMatrix m = matrices[mi];
		for (i = 0; i != m.nodeCount; i++)
		    m.lastNodeVoltages[i] = m.nodeVoltages[i];
	    }
//	    console("set lastrightside at " + t + " " + lastNodeVoltages);
		
	    tm = System.currentTimeMillis();
	    lit = tm;
	    // Check whether enough time has elapsed to perform an *additional* iteration after
	    // those we have already completed.  But limit total computation time to 50ms (20fps) by default
	    if ((timeStepCount-timeStepCountAtFrameStart)*1000 >= steprate*(tm-lastIterTime) || (tm-app.ui.lastFrameTime > frameTimeLimit))
		break;
	    if (!app.simRunning)
		break;
	} // for (iter = 1; ; iter++)
	lastIterTime = lit;
	if (delayWireProcessing)
	    calcWireCurrents();
//	System.out.println((System.currentTimeMillis()-lastFrameTime)/(double) iter);
    }

    // set node voltages given right side found by solving one matrix
    void applySolvedRightSide(CircuitMatrix m) {
	int j;
	for (j = 0; j != m.size; j++) {
	    double res = m.rightSide[j];
	    if (Double.isNaN(res)) {
		converged = false;
		break;
	    }
	    if (j < m.nodeCount) {
		m.nodeVoltages[j] = res;
	    }
	}
	// set currents for voltage sources in this matrix
	for (j = 0; j != m.voltageSourceList.size(); j++) {
	    VoltageSource vs = m.voltageSourceList.get(j);
	    double res = m.rightSide[vs.row-1];
	    if (!Double.isNaN(res))
		vs.elm.setCurrent(vs, res);
	}
	setNodeVoltages(m, m.nodeVoltages);
    }

    // set node voltages in each element given an array of node voltages for one matrix
    void setNodeVoltages(CircuitMatrix m, double nv[]) {
	int j, k;
	for (j = 0; j != m.nodeList.size(); j++) {
	    CircuitNode cn = m.nodeList.get(j);
	    double res = nv[cn.row-1];
	    for (k = 0; k != cn.links.size(); k++) {
		CircuitNodeLink cnl = cn.links.elementAt(k);
		cnl.elm.setNodeVoltage(cnl.num, res);
	    }
	}
    }
    
    // we removed wires from the matrix to speed things up.  in order to display wire currents,
    // we need to calculate them now.
    void calcWireCurrents() {
	int i, j;

	for (i = 0; i != wireInfoList.size(); i++) {
	    WireSegment ws = wireInfoList.get(i);
	    double cur = 0;

	    if (ws.post == 0) {
		// resolve from endpoint0 (position-based neighbors)
		Point p = ws.wire.getPost(ws.bit);
		for (j = 0; j != ws.neighbors.size(); j++) {
		    CircuitElm ce = ws.neighbors.get(j);
		    cur += ce.getCurrentIntoNode(ce.getNodeAtPoint(p));
		}
	    } else {
		if (ws.endpoint1 != null && ws.endpoint1.startsWith("label:")) {
		    // label neighbors: use their already-computed current
		    if (ws.labelNeighbors != null)
			for (j = 0; j != ws.labelNeighbors.size(); j++)
			    cur += ws.labelNeighbors.get(j).current;
		} else {
		    // position-based neighbors at endpoint1
		    Point p = ws.wire.getConnectedPost(ws.bit);
		    for (j = 0; j != ws.neighbors.size(); j++) {
			CircuitElm ce = ws.neighbors.get(j);
			cur += ce.getCurrentIntoNode(ce.getNodeAtPoint(p));
		    }
		}
	    }
	    // get correct current polarity
	    if (ws.post != 0)
		cur = -cur;
	    ws.wire.setWireCurrent(ws.bit, cur);
	    ws.current = cur;
	}
    }
    

    public CustomCompositeModel getCircuitAsComposite() {
	int i;
	Document elmDoc = XMLParser.createDocument();
	Element elmRoot = elmDoc.createElement("elms");
	elmDoc.appendChild(elmRoot);
	CustomLogicModel.clearDumpedFlags();
	DiodeModel.clearDumpedFlags();
	TransistorModel.clearDumpedFlags();
	MosfetModel.clearDumpedFlags();
	RelayModel.clearDumpedFlags();
        Vector<LabeledNodeElm> sideLabels[] = new Vector[] {
            new Vector<LabeledNodeElm>(), new Vector<LabeledNodeElm>(),
            new Vector<LabeledNodeElm>(), new Vector<LabeledNodeElm>()
        };
	Vector<ExtListEntry> extList = new Vector<ExtListEntry>();
	boolean sel = app.isSelection();
	    
	// Temporarily open any closed switches so the model's nn node IDs reflect
	// open topology.  buildCompNodeList() can then merge them when loaded closed.
	Vector<SwitchElm> closedSwitches = new Vector<SwitchElm>();
	for (i = 0; i != app.elmList.size(); i++) {
	    CircuitElm ce = app.elmList.get(i);
	    if (ce instanceof SwitchElm && ((SwitchElm) ce).position == 0) {
		closedSwitches.add((SwitchElm) ce);
		((SwitchElm) ce).position = 1;
	    }
	}

	// redo node allocation to avoid auto-assigning ground
	if (!preStampCircuit(true)) {
	    for (SwitchElm se : closedSwitches) se.position = 0;
	    return null;
	}

	// restore switch positions
	for (SwitchElm se : closedSwitches) se.position = 0;

	boolean used[] = new boolean[nodeList.size()];
	boolean extnodes[] = new boolean[nodeList.size()];
	    
	// find all the labeled nodes, get a list of them, and create a node number map
	for (i = 0; i != elmList.size(); i++) {
	    CircuitElm ce = getElm(i);
	    if (sel && !ce.isSelected())
		continue;
	    if (ce instanceof LabeledNodeElm) {
		LabeledNodeElm lne = (LabeledNodeElm) ce;
		String label = lne.text;
		if (lne.isInternal())
		    continue;
		
		// already added to list?
		if (extnodes[ce.getNode(0).index])
		    continue;

	    int side = ChipElm.SIDE_W;
	    if (Math.abs(ce.dx) >= Math.abs(ce.dy) && ce.dx > 0) side = ChipElm.SIDE_E;
	    if (Math.abs(ce.dx) <= Math.abs(ce.dy) && ce.dy < 0) side = ChipElm.SIDE_N;
	    if (Math.abs(ce.dx) <= Math.abs(ce.dy) && ce.dy > 0) side = ChipElm.SIDE_S;

		// create ext list entry for external nodes
	    sideLabels[side].add(lne);
		for (int j = 0; j < lne.busWidth; j++) {
		    extnodes[ce.getNode(j).index] = true;
		    if (ce.getNode(j).index == 0) {
			Window.alert("Node \"" + lne.text + "\" can't be connected to ground");
			return null;
		    }
		}
	    }
	}
	    
        Collections.sort(sideLabels[ChipElm.SIDE_W], (LabeledNodeElm a, LabeledNodeElm b) -> Integer.signum(a.y - b.y));
        Collections.sort(sideLabels[ChipElm.SIDE_E], (LabeledNodeElm a, LabeledNodeElm b) -> Integer.signum(a.y - b.y));
        Collections.sort(sideLabels[ChipElm.SIDE_N], (LabeledNodeElm a, LabeledNodeElm b) -> Integer.signum(a.x - b.x));
        Collections.sort(sideLabels[ChipElm.SIDE_S], (LabeledNodeElm a, LabeledNodeElm b) -> Integer.signum(a.x - b.x));

        for (int side = 0; side < sideLabels.length; side++) {
            for (int pos = 0; pos < sideLabels[side].size(); pos++) {
                LabeledNodeElm lne = sideLabels[side].get(pos);
		for (int j = 0; j < lne.busWidth; j++) {
		    ExtListEntry ent = new ExtListEntry(lne.text, lne.getNode(j).index, pos, side);
		    ent.busWidth = lne.busWidth;
		    ent.busZ = j;
		    extList.add(ent);
		}
            }
        }

	boolean dumpAll = true;

	// build list of elements to dump, separating out non-essential elements.
	// use app.elmList (not elmList) to avoid including flattened composite children.
	Vector<CircuitElm> dumpList = new Vector<CircuitElm>();
	Vector<CircuitElm> extraList = new Vector<CircuitElm>();
	for (i = 0; i != app.elmList.size(); i++) {
	    CircuitElm ce = app.elmList.get(i);
	    if (sel && !ce.isSelected())
		continue;
	    if (ce instanceof WireElm || ce instanceof RoutedWireElm || ce instanceof LabeledNodeElm || ce instanceof ScopeElm ||
		    ce instanceof GraphicElm || ce instanceof GroundElm) {
		if (dumpAll)
		    extraList.add(ce);
	    } else
		dumpList.add(ce);
	}
	dumpList.addAll(extraList);

	// output all the elements as XML
	for (i = 0; i != dumpList.size(); i++) {
	    CircuitElm ce = dumpList.get(i);
	    int j;
	    // build nn (node list) string
	    String nn = "";
	    for (j = 0; j != ce.getPostCount(); j++) {
		int n = ce.getNode(j).index;
		used[n] = true;
		if (nn.length() > 0)
		    nn += " ";
		nn += n;
	    }
	    Element child = elmDoc.createElement(ce.getXmlDumpType());
	    XMLSerializer.dumpAttr(child, "nn", nn);
	    ce.dumpXml(elmDoc, child);
	    // remove child elements (state) since this is a model definition, not an instance.
	    // preserve text nodes (used by RoutedWireElm for route points).
	    for (Node cn = child.getFirstChild(); cn != null; ) {
		Node next = cn.getNextSibling();
		if (cn.getNodeType() == Node.ELEMENT_NODE)
		    child.removeChild(cn);
		cn = next;
	    }
	    if (!dumpAll)
		child.removeAttribute("x");
	    elmRoot.appendChild(child);
	}

	for (i = 0; i != extList.size(); i++) {
	    ExtListEntry ent = extList.get(i);
	    if (!used[ent.node]) {
		Window.alert("Node \"" + ent.name + "\" is not used!");
		return null;
	    }
	}

	CustomCompositeModel ccm = new CustomCompositeModel();
	ccm.elmDoc = elmDoc;
	ccm.extList = extList;

	console("created model " + XMLSerializer.prettyPrint(elmDoc));
	return ccm;
    }
	
	static void invertMatrix(double a[][], int n) {
	    int ipvt[] = new int[n];
	    lu_factor_dense(a, n, ipvt);
	    int i, j;
	    double b[] = new double[n];
	    double inva[][] = new double[n][n];

	    // solve for each column of identity matrix
	    for (i = 0; i != n; i++) {
		for (j = 0; j != n; j++)
		    b[j] = 0;
		b[i] = 1;
		lu_solve_dense(a, n, ipvt, b);
		for (j = 0; j != n; j++)
		    inva[j][i] = b[j];
	    }

	    // return in original matrix
	    for (i = 0; i != n; i++)
		for (j = 0; j != n; j++)
		    a[i][j] = inva[i][j];
	}
    // Dispatching lu_factor: uses sparse or dense solver based on solverType setting
    static boolean lu_factor(double a[][], int n, int ipvt[], CircuitMatrix cm) {
	SimulationManager sm = theSim;
	if (sm != null && sm.usingSparse) {
	    DMatrixSparseCSC csc = DMatrixSparseCSC.convert(a, DMatrixSparseCSC.EPS);
	    if (cm.sparseLU == null) cm.sparseLU = new SparseLU();
	    return cm.sparseLU.setA(csc);
	}
	return lu_factor_dense(a, n, ipvt);
    }

    // factors a matrix into upper and lower triangular matrices by
    // gaussian elimination.  On entry, a[0..n-1][0..n-1] is the
    // matrix to be factored.  ipvt[] returns an integer vector of pivot
    // indices, used in the lu_solve() routine.
    static boolean lu_factor_dense(double a[][], int n, int ipvt[]) {
	int i,j,k;
	
	// check for a possible singular matrix by scanning for rows that
	// are all zeroes
	for (i = 0; i != n; i++) { 
	    boolean row_all_zeros = true;
	    for (j = 0; j != n; j++) {
		if (a[i][j] != 0) {
		    row_all_zeros = false;
		    break;
		}
	    }
	    // if all zeros, it's a singular matrix
	    if (row_all_zeros)
		return false;
	}
	
        // use Crout's method; loop through the columns
	for (j = 0; j != n; j++) {
	    
	    // calculate upper triangular elements for this column
	    for (i = 0; i != j; i++) {
		double q = a[i][j];
		for (k = 0; k != i; k++)
		    q -= a[i][k]*a[k][j];
		a[i][j] = q;
	    }

	    // calculate lower triangular elements for this column
	    double largest = 0;
	    int largestRow = -1;
	    for (i = j; i != n; i++) {
		double q = a[i][j];
		for (k = 0; k != j; k++)
		    q -= a[i][k]*a[k][j];
		a[i][j] = q;
		double x = Math.abs(q);
		if (x >= largest) {
		    largest = x;
		    largestRow = i;
		}
	    }
	    
	    // pivoting
	    if (j != largestRow) {
		if (largestRow == -1) {
		    console("largestRow == -1");
		    return false;
		}
		double x;
		for (k = 0; k != n; k++) {
		    x = a[largestRow][k];
		    a[largestRow][k] = a[j][k];
		    a[j][k] = x;
		}
	    }

	    // keep track of row interchanges
	    ipvt[j] = largestRow;

	    // check for zeroes; if we find one, it's a singular matrix.
	    // we used to avoid them, but that caused weird bugs.  For example,
	    // two inverters with outputs connected together should be flagged
	    // as a singular matrix, but it was allowed (with weird currents)
	    if (a[j][j] == 0.0) {
		console("didn't avoid zero");
//		a[j][j]=1e-18;
		return false;
	    }

	    if (j != n-1) {
		double mult = 1.0/a[j][j];
		for (i = j+1; i != n; i++)
		    a[i][j] *= mult;
	    }
	}
	return true;
    }

    // Dispatching lu_solve: uses sparse or dense solver based on solverType setting
    static void lu_solve(double a[][], int n, int ipvt[], double b[], CircuitMatrix cm) {
	SimulationManager sm = theSim;
	if (sm != null && sm.usingSparse) {
	    cm.sparseLU.solve(b, b);
	    return;
	}
	lu_solve_dense(a, n, ipvt, b);
    }

    // Solves the set of n linear equations using a LU factorization
    // previously performed by lu_factor.  On input, b[0..n-1] is the right
    // hand side of the equations, and on output, contains the solution.
    static void lu_solve_dense(double a[][], int n, int ipvt[], double b[]) {
	int i;

	// find first nonzero b element
	for (i = 0; i != n; i++) {
	    int row = ipvt[i];

	    double swap = b[row];
	    b[row] = b[i];
	    b[i] = swap;
	    if (swap != 0)
		break;
	}
	
	int bi = i++;
	for (; i < n; i++) {
	    int row = ipvt[i];
	    int j;
	    double tot = b[row];
	    
	    b[row] = b[i];
	    // forward substitution using the lower triangular matrix
	    for (j = bi; j < i; j++)
		tot -= a[i][j]*b[j];
	    b[i] = tot;
	}
	for (i = n-1; i >= 0; i--) {
	    double tot = b[i];
	    
	    // back-substitution using the upper triangular matrix
	    int j;
	    for (j = i+1; j != n; j++)
		tot -= a[i][j]*b[j];
	    b[i] = tot/a[i][i];
	}
    }
    
    double getLabeledNodeVoltage(String name) {
	CircuitNode cn = LabeledNodeElm.getByName(name);
	if (cn == null || cn.index == 0)
	    return 0;
	if (cn.matrix == null)
	    return 0;
	return cn.matrix.nodeVoltages[cn.row-1];
    }

    static class RoutedWireConnection {
	RoutedWireElm wire;
	int wirePost;   // which post of the RoutedWireElm (0 or 1)
	int elmPost;    // which post of the non-routed element

	RoutedWireConnection(RoutedWireElm wire, int wirePost, int elmPost) {
	    this.wire = wire;
	    this.wirePost = wirePost;
	    this.elmPost = elmPost;
	}
    }

}
