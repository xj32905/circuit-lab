package com.lushprojects.circuitjs1.client;

import java.util.Arrays;
import java.util.Date;

import com.google.gwt.canvas.client.Canvas;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.core.client.Callback;
import com.google.gwt.core.client.ScriptInjector;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.Window;

public class ImageExporter {

	static final int CAC_PRINT = 0;
	static final int CAC_IMAGE = 1;
	static final int CAC_SVG   = 2;

	CirSim sim;
	boolean loadedCanvas2SVG = false;

	ImageExporter(CirSim sim) {
		this.sim = sim;
	}

	static String defaultFileName(String ext) {
		Date date = new Date();
		DateTimeFormat dtf = DateTimeFormat.getFormat("yyyyMMdd-HHmm");
		return "circuit-" + dtf.format(date) + ext;
	}

	private static native void electronSaveBinaryFile(String defaultName, String base64Data) /*-{
		$wnd.showSaveDialog(defaultName).then(function (file) {
			if (file.canceled)
				return;
			$wnd.saveFile(file, base64Data, 'base64');
		});
	}-*/;

	private static native void electronSaveTextFile(String defaultName, String data) /*-{
		$wnd.showSaveDialog(defaultName).then(function (file) {
			if (file.canceled)
				return;
			$wnd.saveFile(file, data, 'utf8');
		});
	}-*/;

	void doExportAsImage() {
		if (sim.isElectron()) {
			String dataURL = getCircuitAsCanvas(CAC_IMAGE).toDataUrl();
			String base64 = dataURL.substring(dataURL.indexOf(',')+1);
			electronSaveBinaryFile(defaultFileName(".png"), base64);
			return;
		}
		sim.dialogShowing = new ExportAsImageDialog(CAC_IMAGE);
		sim.dialogShowing.show();
	}

	private static native void clipboardWriteImage(CanvasElement cv) /*-{
		cv.toBlob(function(blob) {
		    var promise = parent.navigator.clipboard.write([new ClipboardItem({ "image/png": blob })]);
		    promise.then(function(x) { console.log(x); });
		});
	}-*/;

	void doImageToClipboard() {
		Canvas cv = getCircuitAsCanvas(CAC_IMAGE);
		clipboardWriteImage(cv.getCanvasElement());
	}

	native void printCanvas(CanvasElement cv) /*-{
	    var img = cv.toDataURL("image/png");
	    var style = $doc.createElement("style");
	    style.id = "circuit-print-style";
	    style.innerHTML = "@media print { body > *:not(#circuit-print-overlay) { display: none !important; } } #circuit-print-overlay { display: none; } @media print { html, body { height: 100%; margin: 0; padding: 0; } @page { size: auto; margin: 10mm; } #circuit-print-overlay { display: flex !important; align-items: center; justify-content: center; width: 100%; height: 100%; } #circuit-print-overlay img { max-width: 100%; max-height: 100%; width: auto; height: auto; object-fit: contain; page-break-inside: avoid; } }";
	    $doc.head.appendChild(style);
	    var overlay = $doc.createElement("div");
	    overlay.id = "circuit-print-overlay";
	    var imgEl = $doc.createElement("img");
	    imgEl.src = img;
	    overlay.appendChild(imgEl);
	    $doc.body.appendChild(overlay);
	    setTimeout(function() {
	        $wnd.print();
	        $doc.body.removeChild(overlay);
	        $doc.head.removeChild(style);
	    }, 500);
	}-*/;

	void doPrint() {
	    Canvas cv = getCircuitAsCanvas(CAC_PRINT);
	    printCanvas(cv.getCanvasElement());
	}

	boolean initializeSVGScriptIfNecessary(final String followupAction) {
		// load canvas2svg if we haven't already
		if (!loadedCanvas2SVG) {
			ScriptInjector.fromUrl("canvas2svg.js").setCallback(new Callback<Void,Exception>() {
				public void onFailure(Exception reason) {
					Window.alert("Can't load canvas2svg.js.");
				}
				public void onSuccess(Void result) {
					loadedCanvas2SVG = true;
					if (followupAction.equals("doExportAsSVG")) {
						doExportAsSVG();
					} else if (followupAction.equals("doExportAsSVGFromAPI")) {
						doExportAsSVGFromAPI();
					}
				}
			}).inject();
			return false;
		}
		return true;
	}

	void doExportAsSVG() {
		if (!initializeSVGScriptIfNecessary("doExportAsSVG")) {
			return;
		}
		if (sim.isElectron()) {
			electronSaveTextFile(defaultFileName(".svg"), getCircuitAsSVG());
			return;
		}
		sim.dialogShowing = new ExportAsImageDialog(CAC_SVG);
		sim.dialogShowing.show();
	}

	public void doExportAsSVGFromAPI() {
		if (!initializeSVGScriptIfNecessary("doExportAsSVGFromAPI")) {
			return;
		}
		String svg = getCircuitAsSVG();
		sim.jsInterface.callSVGRenderedHook(svg);
	}

	// max canvas dimensions we'll target; chosen to stay under the tightest
	// common browser limit (Chrome caps canvas area at 16384*16384 = 268,435,456 px)
	static final int MAX_CANVAS_DIM = 16000;
	static final long MAX_CANVAS_AREA = 250_000_000L;

	public Canvas getCircuitAsCanvas(int type) {
	    	// create canvas to draw circuit into
	    	Canvas cv = Canvas.createIfSupported();
	    	Rectangle bounds = sim.getCircuitBounds();

		// add some space on edges because bounds calculation is not perfect
	    	int wmargin = 140;
	    	int hmargin = 100;
	    	double baseW = bounds.width+wmargin;
	    	double baseH = bounds.height+hmargin;

	    	// oversample by up to 2x for quality, but clamp so the canvas never
	    	// exceeds browser size limits (which otherwise makes toDataURL() fail
	    	// silently, producing an empty image)
	    	double factor = 2;
	    	factor = Math.min(factor, MAX_CANVAS_DIM/baseW);
	    	factor = Math.min(factor, MAX_CANVAS_DIM/baseH);
	    	factor = Math.min(factor, Math.sqrt(MAX_CANVAS_AREA/(baseW*baseH)));

	    	int w = (int) Math.round(bounds.width*factor+wmargin) ;
	    	int h = (int) Math.round(bounds.height*factor+hmargin) ;
	    	cv.setCoordinateSpaceWidth(w);
	    	cv.setCoordinateSpaceHeight(h);

		Context2d context = cv.getContext2d();
		drawCircuitInContext(context, type, bounds, w, h);
		return cv;
	}

	// create SVG context using canvas2svg
	native static Context2d createSVGContext(int w, int h) /*-{
	    return new C2S(w, h);
	}-*/;

	native static String getSerializedSVG(Context2d context) /*-{
	    return context.getSerializedSvg();
	}-*/;

	public String getCircuitAsSVG() {
	    Rectangle bounds = sim.getCircuitBounds();

	    // add some space on edges because bounds calculation is not perfect
	    int wmargin = 140;
	    int hmargin = 100;
	    int w = (bounds.width+wmargin) ;
	    int h = (bounds.height+hmargin) ;
	    Context2d context = createSVGContext(w, h);
	    drawCircuitInContext(context, CAC_SVG, bounds, w, h);
	    return getSerializedSVG(context);
	}

	void drawCircuitInContext(Context2d context, int type, Rectangle bounds, int w, int h) {
		Graphics g = new Graphics(context);
		context.setTransform(1, 0, 0, 1, 0, 0);
	    	double oldTransform[] = Arrays.copyOf(sim.transform, 6);

	        double scale = 1;

		// turn on white background, turn off current display
		boolean p = sim.menus.printableCheckItem.getState();
		boolean c = sim.menus.dotsCheckItem.getState();
		boolean print = (type == CAC_PRINT);
		if (print)
		    sim.menus.printableCheckItem.setState(true);
	        if (sim.menus.printableCheckItem.getState()) {
	            CircuitElm.whiteColor = Color.black;
	            CircuitElm.lightGrayColor = Color.black;
	            g.setColor(Color.white);
	        } else {
	            CircuitElm.whiteColor = Color.white;
	            CircuitElm.lightGrayColor = Color.lightGray;
	            g.setColor(Color.black);
	        }
	        g.fillRect(0, 0, w, h);
		sim.menus.dotsCheckItem.setState(false);

	    	int wmargin = 140;
	    	int hmargin = 100;
	        if (bounds != null)
	            scale = Math.min(w /(double)(bounds.width+wmargin),
	                             h/(double)(bounds.height+hmargin));

	        // ScopeElms need the transform array to be updated
		sim.transform[0] = sim.transform[3] = scale;
		sim.transform[4] = -(bounds.x-wmargin/2);
		sim.transform[5] = -(bounds.y-hmargin/2);
		context.scale(scale, scale);
		context.translate(sim.transform[4], sim.transform[5]);
		context.setLineCap(Context2d.LineCap.ROUND);

		// draw elements
		for (CircuitElm ce : sim.elmList) {
		    ce.draw(g);
		}
		int i;
		for (i = 0; i != sim.postDrawList.size(); i++) {
		    CircuitElm.drawPost(g, sim.postDrawList.get(i));
		}

		// restore everything
		sim.menus.printableCheckItem.setState(p);
		sim.menus.dotsCheckItem.setState(c);
		sim.transform = oldTransform;
	}
}
