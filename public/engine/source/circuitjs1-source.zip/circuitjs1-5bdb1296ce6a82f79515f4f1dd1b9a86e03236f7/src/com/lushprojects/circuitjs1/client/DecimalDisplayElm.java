/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Document;

class DecimalDisplayElm extends ChipElm {
    int bitCount;
    int displayMode; // 0=decimal, 1=hex, 2=octal

    public DecimalDisplayElm(int xx, int yy) {
	super(xx, yy);
	bitCount = 4;
	setupPins();
    }
    public DecimalDisplayElm(int xa, int ya, int xb, int yb, int f,
		    StringTokenizer st) {
	super(xa, ya, xb, yb, f, st);
	bitCount = 4;
	try {
	    bitCount = Integer.parseInt(st.nextToken());
	    displayMode = Integer.parseInt(st.nextToken());
	} catch (Exception e) {}
	setupPins();
    }
    String getChipName() {
	switch (displayMode) {
	case 1:  return "hex display";
	case 2:  return "octal display";
	default: return "decimal display";
	}
    }
    
    void draw(Graphics g) {
        drawChip(g);
        int xl = x+cspc + flippedSizeX*cspc;
        int yl = y-cspc + flippedSizeY*cspc;
	if (isFlippedXY())
	    yl += ((flags & FLAG_FLIP_Y) != 0) ? -cspc/2 : cspc/2;
        g.save();
        g.setFont(new Font("SansSerif", 0, 15*csize));
        g.setColor(whiteColor);
        g.context.setTextBaseline("middle");
        int i;
        int value = 0;
        for (i = 0; i != bitCount; i++)
            if (pins[i].value)
        	value |= 1<<i;
        String str;
        switch (displayMode) {
        case 1:  str = Integer.toHexString(value).toUpperCase(); break;
        case 2:  str = Integer.toOctalString(value); break;
        default: str = String.valueOf(value); break;
        }
        int w=(int)g.context.measureText(str).getWidth();
        g.drawString(str, xl+5*csize-w/2, yl);
        g.restore();
    }
    
    String dump() { return super.dump() + " " + bitCount + " " + displayMode; }

    void dumpXml(Document doc, Element elem) {
        super.dumpXml(doc, elem);
        XMLSerializer.dumpAttr(elem, "bc", bitCount);
        XMLSerializer.dumpAttr(elem, "dm", displayMode);
    }

    void undumpXml(XMLDeserializer xml) {
        super.undumpXml(xml);
        bitCount = xml.parseIntAttr("bc", bitCount);
        displayMode = xml.parseIntAttr("dm", displayMode);
	setupPins();
    }
    
    String getXmlDumpType() { return "dd"; }
    boolean allowBus() { return true; }

    void setupPins() {
	sizeX = 3;
	sizeY = useBus() ? 2 : bitCount;
	pins = new Pin[bitCount];
	makeBitPins(bitCount, 0, SIDE_W, 0, "I", false, false, false);
	allocNodes();
    }
    int getPostCount() { return bitCount; }
    int getDumpType() { return 419; }
    int getVoltageSourceCount() { return 0; }
    public EditInfo getChipEditInfo(int n) {
        if (n == 0)
            return new EditInfo("# of Bits", bitCount, 1, 8).
                setDimensionless();
        if (n == 1) {
            EditInfo ei = new EditInfo("Display Mode", 0, -1, -1);
            ei.choice = new Choice();
            ei.choice.add("Decimal");
            ei.choice.add("Hexadecimal");
            ei.choice.add("Octal");
            ei.choice.select(displayMode);
            return ei;
        }
        return null;
    }
    public void setChipEditValue(int n, EditInfo ei) {
        if (n == 0) {
            if (ei.value >= 1 && ei.value <= 16) {
                int newBitCount = (int) ei.value;
                if (newBitCount != bitCount) {
                    bitCount = newBitCount;
                    setupPins();
                    setPoints();
                }
            } else
                ei.setError("must be between 1 and 16");
            return;
        }
        if (n == 1)
            displayMode = ei.choice.getSelectedIndex();
    }

}
    
