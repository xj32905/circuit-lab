package com.lushprojects.circuitjs1.client;

import java.util.Vector;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;

public class OptocouplerElm extends CompositeElm {
    int csize, cspc, cspc2;
    int rectPointsX[], rectPointsY[];
    double curCounts[];
    double ctr = 1.0; // current transfer ratio (1.0 = 100%)

    private static String modelString = "DiodeElm 6 1\rCCCSElm 1 2 3 4\rNTransistorElm 3 4 5";
    private static int[] modelExternalNodes = { 6, 2, 4, 5 };

    DiodeElm diode;
    TransistorElm transistor;
    Vector<DiodeModel> models;

    public OptocouplerElm(int xx, int yy) {
	super(xx, yy, modelString, modelExternalNodes);
	noDiagonal = true;
	initOptocoupler();
	diode.modelName = "default-optocoupler-led";
	diode.setup();
    }

    public OptocouplerElm(int xa, int ya, int xb, int yb, int f, StringTokenizer st) {
	// pass st=null since we don't need to undump any of the sub-elements
	super(xa, ya, xb, yb, f, null, modelString, modelExternalNodes);
	noDiagonal = true;
	initOptocoupler();
    }

    void dumpXmlModel(Document doc) {
	DiodeModel model = diode.model;
	if (!(model.builtIn || model.dumped))
	    model.dumpXml(doc);
    }

    void dumpXml(Document doc, Element elem) {
	DiodeModel model = diode.model;
	if (!(model.builtIn || model.dumped))
	    model.dumpXml(doc);
	super.dumpXml(doc, elem);
	XMLSerializer.dumpAttr(elem, "ctr", ctr);
	XMLSerializer.dumpAttr(elem, "dmo", diode.modelName);
    }

    void undumpXml(XMLDeserializer xml) {
	super.undumpXml(xml);
	ctr = xml.parseDoubleAttr("ctr", ctr);
	// "ix" is set on state-restore calls (from CompositeElm.dumpXmlState); absent on
	// definition/top-level loads where a missing "dmo" should fall back to "default".
	String defaultDmo = (xml.parseStringAttr("ix", null) != null) ? diode.modelName : "default";
	diode.modelName = xml.parseStringAttr("dmo", defaultDmo);
	initOptocoupler();
	diode.setup();
    }


    private void initOptocoupler() {
	csize = 2;
	cspc = 8*2;
	cspc2 = cspc*2;
	diode = (DiodeElm) compElmList.get(0);
	CCCSElm cccs = (CCCSElm) compElmList.get(1);
	
	// from http://www.cel.com/pdf/appnotes/an3017.pdf
	// the base expression models a ~100% CTR device; we scale by ctr
	cccs.setExpr(ctr + "*max(0,min(.0001, select(i-.003, (-80000000000*(i)^5+800000000*(i)^4-3000000*(i)^3+5177.2*(i)^2+.2453*(i)-.00005)*1.04/700, (9000000*(i)^5-998113*(i)^4+42174*(i)^3-861.32*(i)^2+9.0836*(i)-.0078)*.945/700)))");
	
	transistor = (TransistorElm) compElmList.get(2);
	transistor.setBeta(700);
	curCounts = new double[4];
    }

    public void reset() {
	super.reset();
	curCounts = new double[4];
    }

    public boolean getConnection(int n1, int n2) {
	return n1/2 == n2/2;
    }

    void draw(Graphics g) {
        g.setColor(needsHighlight() ? selectColor : lightGrayColor);
        drawThickPolygon(g, rectPointsX, rectPointsY, 4);
	
        // draw stubs
        int i;
        for (i = 0; i != 4; i++) {
            setVoltageColor(g, volts[i]);
            Point a = posts[i];
            Point b = stubs[i];
            drawThickLine(g, a, b);
            curCounts[i] = updateDotCount(-getCurrentIntoNode(i), curCounts[i]);
            drawDots(g, a, b, curCounts[i]);
        }
        
        diode.draw(g);
        transistor.draw(g);
        
        drawPosts(g);

        // draw little arrows
        g.setColor(lightGrayColor);
	int dx = isFlippedX() ? -1 : 1;
        int sx = stubs[0].x+2*dx;
        int sy = (stubs[0].y+stubs[1].y)/2;
        for (i = 0; i != 2; i++) {
            int y = sy+i*10-5;
            Point p1 = new Point(sx,       y);
            Point p2 = new Point(sx+20*dx, y);
            Polygon p = calcArrow(p1, p2, 5, 2);
            g.fillPolygon(p);
            g.drawLine(sx+10*dx, y, sx+15*dx, y);
        }
    }

    Point stubs[];
    
    void setPoints() {
	super.setPoints();
	
	// adapted from ChipElm
        int hs = cspc;
        int x0 = x+cspc2; int y0 = y;
        int xr = x0-cspc;
        int yr = y0-cspc/2;
        int sizeX = 2;
        int sizeY = 2;
        int xs = sizeX*cspc2;
        int ys = sizeY*cspc2-cspc;
        rectPointsX = new int[] { xr, xr+xs, xr+xs, xr };
        rectPointsY = new int[] { yr, yr, yr+ys, yr+ys };
        setBbox(xr, yr, rectPointsX[2], rectPointsY[2]);
        stubs = new Point[4];
//        setPin(0, x0, y0, 1, 0, 0, -1, 0, 0);
//        setPin(1, x0, y0, 1, 0, 0,  1, 0, ys-cspc2);
//        setPin(2, x0, y0, 1, 0, 0, -1, 0, 0);
//        setPin(3, x0, y0, 1, 0, 0,  1, 0, ys-cspc2);
        setPin(0, x0, y0, 0, 1, -1, 0, 0, 0);
        setPin(1, x0, y0, 0, 1, -1, 0, 0, 0);
        setPin(2, x0, y0, 0, 1, 1, 0, xs-cspc2, 0);
        setPin(3, x0, y0, 0, 1, 1, 0, xs-cspc2, 0);
        int dx = isFlippedX() ? -1 : 1;
        diode.setPosition(posts[0].x+32*dx, posts[0].y, posts[1].x+32*dx, posts[1].y);
        stubs[0] = diode.getPost(0);
        stubs[1] = diode.getPost(1);
        
        int midp = (posts[2].y+posts[3].y)/2;
	transistor.setFlipped(isFlippedY());
        transistor.setPosition(posts[2].x-40*dx, midp, posts[2].x-24*dx, midp);
        stubs[2] = transistor.getPost(1);
        stubs[3] = transistor.getPost(2);
    }

    boolean isFlippedX() { return (flags & ChipElm.FLAG_FLIP_X) != 0; }
    boolean isFlippedY() { return (flags & ChipElm.FLAG_FLIP_Y) != 0; }
    boolean canFlipXY()  { return false; }

    void flipX(int center2, int count) {
	flags ^= ChipElm.FLAG_FLIP_X;
	if (count != 1) {
	    int xs = 3*cspc2;
	    x  = center2-x - xs;
	    x2 = center2-x2;
	}
	setPoints();
    }

    void flipY(int center2, int count) {
	flags ^= ChipElm.FLAG_FLIP_Y;
	if (count != 1) {
	    int ys = 1*cspc2;
	    y  = center2-y - ys;
	    y2 = center2-y2;
	}
	setPoints();
    }

    void setPin(int n, int px, int py, int dx, int dy, int dax, int day, int sx, int sy) {
	int pos = n % 2; 
	if (isFlippedX()) {
	    dx = -dx;
	    dax = -dax;
	    px += cspc2;
	    sx = -sx;
	}
	if (isFlippedY()) {
	    dy = -dy;
	    day = -day;
	    py += cspc2;
	    sy = -sy;
	}

        int xa = px+cspc2*dx*pos+sx;
        int ya = py+cspc2*dy*pos+sy;
        setPost(n, new Point(xa+dax*cspc2, ya+day*cspc2));
        stubs[n] = new Point(xa+dax*cspc , ya+day*cspc );
    }
    
    @Override
    public int getDumpType() {
	return 407;
    }

    void getInfo(String arr[]) {
	arr[0] = "optocoupler";
	arr[1] = "CTR Scale = " + showFormat.format(ctr);
	arr[2] = "Iin = " + getCurrentText(getCurrentIntoNode(0));
	arr[3] = "Iout = " + getCurrentText(getCurrentIntoNode(2));
    }

    public EditInfo getEditInfo(int n) {
	if (n == 0)
	    return new EditInfo("CTR Scale", ctr, 0, 0).setDimensionless();
	if (n == 1) {
	    EditInfo ei = new EditInfo("LED Model", 0, -1, -1);
	    models = DiodeModel.getModelList(false);
	    ei.choice = new Choice();
	    for (int i = 0; i != models.size(); i++) {
		DiodeModel dm = models.get(i);
		ei.choice.add(dm.getDescription());
		if (dm == diode.model)
		    ei.choice.select(i);
	    }
	    return ei;
	}
	return null;
    }

    public void updateModels() {
	diode.setup();
    }

    public void setEditValue(int n, EditInfo ei) {
	if (n == 0 && ei.value > 0) {
	    ctr = ei.value;
	    initOptocoupler();
	}
	if (n == 1) {
	    diode.model = models.get(ei.choice.getSelectedIndex());
	    diode.modelName = diode.model.name;
	    diode.setup();
	}
    }
}
