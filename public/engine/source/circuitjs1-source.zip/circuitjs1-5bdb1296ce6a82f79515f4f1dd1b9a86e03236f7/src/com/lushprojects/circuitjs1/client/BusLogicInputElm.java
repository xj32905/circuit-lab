/*
    Copyright (C) Paul Falstad and Iain Sharp

    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Document;

class BusLogicInputElm extends SwitchElm {
    int busWidth = 4;
    int value = 0;
    double hiV = 5, loV = 0;
    VoltageSource voltageSources[];
    double currents[];

    public BusLogicInputElm(int xx, int yy) {
	super(xx, yy);
    }

    void dumpXml(Document doc, Element elem) {
	super.dumpXml(doc, elem);
	XMLSerializer.dumpAttr(elem, "bw", busWidth);
	if (value != 0)
	    XMLSerializer.dumpAttr(elem, "va", value);
	if (hiV != 5)
	    XMLSerializer.dumpAttr(elem, "hi", hiV);
	if (loV != 0)
	    XMLSerializer.dumpAttr(elem, "lo", loV);
    }

    void undumpXml(XMLDeserializer xml) {
	super.undumpXml(xml);
	busWidth = xml.parseIntAttr("bw", busWidth);
	value = xml.parseIntAttr("va", 0);
	hiV = xml.parseDoubleAttr("hi", hiV);
	loV = xml.parseDoubleAttr("lo", loV);
    }

    int getDumpType() { return 0; }
    int getPostCount() { return busWidth; }
    int getNumHandles() { return 1; }
    int getPostWidth(int n) { return busWidth; }
    int getVoltageSourceCount() { return busWidth; }

    Point getPost(int n) {
	return new Point(x, y, n);
    }

    void setVoltageSource(int n, VoltageSource v) {
	if (voltageSources == null || voltageSources.length != busWidth) {
	    voltageSources = new VoltageSource[busWidth];
	    currents = new double[busWidth];
	}
	voltageSources[n] = v;
    }

    void setCurrent(VoltageSource vs, double c) {
	for (int i = 0; i < busWidth; i++)
	    if (voltageSources[i] == vs) {
		currents[i] = current = c;
		break;
	    }
    }

    double getCurrentIntoNode(int n) {
	return currents[n];
    }

    void setPoints() {
	super.setPoints();
	lead1 = new Point();
    }

    void draw(Graphics g) {
	g.save();
	Font f = new Font("SansSerif", Font.BOLD, 20);
	g.setFont(f);
	g.setColor(needsHighlight() ? selectColor : whiteColor);
	String s = "" + value;
	interpPoint(point1, point2, lead1, 1 - ((int) g.context.measureText(s).getWidth() / 2 + 8) / dn);
	setBbox(point1, lead1, 0);
	drawCenteredText(g, s, x2, y2, true);
	setVoltageColor(g, volts[0]);
	drawThickLine(g, point1, lead1, 5);
	if (currents != null) {
	    current = 0;
	    for (int i = 0; i < currents.length; i++)
		current += currents[i];
	}
	updateDotCount();
	drawDots(g, point1, lead1, -curcount);
	drawPosts(g);
	g.restore();
    }

    Rectangle getSwitchRect() {
	return new Rectangle(x2 - 10, y2 - 10, 20, 20);
    }

    void toggle() {
	value++;
	if (value >= (1 << busWidth))
	    value = 0;
    }

    void stamp() {
	for (int i = 0; i < busWidth; i++) {
	    double v = ((value & (1 << i)) != 0) ? hiV : loV;
	    sim.stampVoltageSource(CircuitNode.ground, nodes[i], voltageSources[i], v);
	}
    }

    void calculateCurrent() {}
    boolean hasGroundConnection(int n) { return true; }
    boolean isWireEquivalent() { return false; }
    boolean isRemovableWire() { return false; }

    String getXmlDumpType() { return "bli"; }

    void getInfo(String arr[]) {
	arr[0] = "bus input (" + busWidth + ")";
	arr[1] = "value = " + value;
	arr[2] = "hex = 0x" + Integer.toHexString(value).toUpperCase();
    }
    int getShortcut() { return 0; }

    public EditInfo getEditInfo(int n) {
	if (n == 0)
	    return new EditInfo("Bus Width", busWidth, 2, 32).setDimensionless();
	if (n == 1)
	    return new EditInfo("Value", value).setDimensionless();
	if (n == 2)
	    return new EditInfo("High Voltage", hiV).setUnitStep();
	if (n == 3)
	    return new EditInfo("Low Voltage", loV).setUnitStep();
	return null;
    }
    public void setEditValue(int n, EditInfo ei) {
	if (n == 0) {
	    if (ei.value >= 2) {
		busWidth = (int) ei.value;
		allocNodes();
	    } else
		ei.setError("must be >= 2");
	}
	if (n == 1)
	    value = (int) ei.value;
	if (n == 2)
	    hiV = ei.value;
	if (n == 3)
	    loV = ei.value;
    }
}
