package com.lushprojects.circuitjs1.client;

import com.google.gwt.dom.client.Style.FontWeight;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.user.client.Command;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.FocusWidget;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Panel;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.lushprojects.circuitjs1.client.util.Locale;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;

import java.util.Vector;

class ScopeCheckBox extends CheckBox {
    String menuCmd;
    
    ScopeCheckBox(String text, String menu) {
	super(text);
	menuCmd = menu;
    }
    
    void setValue(boolean x) {
	if (getValue() == x)
	    return;
	super.setValue(x);
    }
}



public class ScopePropertiesDialog extends Dialog implements ValueChangeHandler<Boolean> {

	
Panel fp, channelButtonsp, channelSettingsp;
HorizontalPanel hp;
HorizontalPanel vModep;
CirSim sim;
//RichTextArea textBox;
TextArea textArea;
RadioButton autoButton, maxButton, manualButton;
RadioButton acButton, dcButton;
CheckBox scaleBox, voltageBox, currentBox, powerBox, peakBox, negPeakBox, p2pBox, freqBox, spectrumBox, manualScaleBox;
CheckBox rmsBox, dutyBox, viBox, xyBox, resistanceBox, chargeBox, ibBox, icBox, ieBox, vbeBox, vbcBox, vceBox, vceIcBox, logSpectrumBox, averageBox;
CheckBox elmInfoBox, phaseAngleBox;
TextBox labelTextBox, manualScaleTextBox, divisionsTextBox;
Button applyButton, scaleUpButton, scaleDownButton;
Scrollbar speedBar, positionBar, trailBar;
Label trailLabel;
Scope scope;
Grid grid, vScaleGrid, hScaleGrid;
int nx, ny;
Label scopeSpeedLabel, manualScaleLabel,vScaleList, manualScaleId, positionLabel, divisionsLabel;
expandingLabel vScaleLabel, hScaleLabel;
// Trigger controls
RadioButton trigFreeRunButton, trigNormalButton, trigAutoButton;
RadioButton trigRisingButton, trigFallingButton;
TextBox triggerLevelTextBox;
Grid triggerGrid;
expandingLabel triggerLabel;
HorizontalPanel trigModep, trigEdgep;
Vector <Button> chanButtons = new Vector <Button>();
int plotSelection = 0;
labelledGridManager gridLabels;
// XY plot settings controls
Grid xySettingsGrid;
ListBox xyPlotXBox, xyPlotYBox, xyBrightnessBox, xyRedBox, xyGreenBox, xyBlueBox;
int xySettingsRow = -1;
expandingLabel xyPlotsLabel;
	
    class PlotClickHandler implements ClickHandler {
	int num;

	public PlotClickHandler(int n) {
	    num = n;
	}

	public void onClick(ClickEvent event) {
	    plotSelection = num;
	    for (int i =0; i < chanButtons.size(); i++) {
		if (i==num)
		    chanButtons.get(i).addStyleName("chsel");
		else
		    chanButtons.get(i).removeStyleName("chsel");
	    }
	    updateUi();
	}
    }
    
    class manualScaleTextHandler implements ValueChangeHandler<String> {
	
	public void onValueChange(ValueChangeEvent<String> event) {
	    apply();
	    updateUi();
	}
	
    }
    
    class downClickHandler implements ClickHandler{
	public downClickHandler() {
	}
	
	public void onClick(ClickEvent event) {
	    double lasts, s;
	if (!scope.isManualScale() || plotSelection>scope.visiblePlots.size())
		return;
	    double d = getManualScaleValue();
	    if (d==0)
		return;
	    d=d*0.999; // Go just below last check point
	    s=Scope.MIN_MAN_SCALE;
	    lasts=s;
	    for(int a=0; s<d; a++) { // Iterate until we go over the target and then use the last value
		lasts = s;
		s*=Scope.multa[a%3];
	    }
	    scope.setManualScaleValue(plotSelection, lasts);
	    updateUi();
	}
	
    }

    
    class upClickHandler implements ClickHandler{
	public upClickHandler() {
	}
	
	public void onClick(ClickEvent event) {
	    double  s;
	if (!scope.isManualScale() || plotSelection>scope.visiblePlots.size())
		return;
	    double d = getManualScaleValue();
	    if (d==0)
		return;
	    s=nextHighestScale(d);
	    scope.setManualScaleValue(plotSelection, s);
	    updateUi();
	}
	
    }
    
    static double nextHighestScale(double d) {
	    d=d*1.001; // Go just above last check point
	    double s;
	    s=Scope.MIN_MAN_SCALE;
	    for(int a=0; s<d; a++) { // Iterate until we go over the target
		s*=Scope.multa[a%3];
	    }
	    return s;
    }
    
    void positionBarChanged() {
	if (!scope.isManualScale() || plotSelection>scope.visiblePlots.size())
	    return;
	int p = positionBar.getValue();
	scope.setPlotPosition(plotSelection, p);
    }
    
    String getChannelButtonLabel(int i) {
	    ScopePlot p = scope.visiblePlots.get(i);
	    String l = "<span style=\"color: "+p.color+";\">&#x25CF;</span>&nbsp;CH "+String.valueOf(i+1);
	    switch (p.units) {
	    	case Scope.UNITS_V: 
	    	    l += " (V)";
	    	    break;
	    	case Scope.UNITS_A:
	    	    l += " (I)";
	    	    break;
	    	case Scope.UNITS_OHMS:
	    	    l += " (R)";
	    	    break;
	    	case Scope.UNITS_W:
	    	    l += " (P)";
	    	    break;
	    	case Scope.UNITS_C:
	    	    l += " (Q)";
	    	    break;
	    }
	    return l;
	
    }
    
    void updateChannelButtons() {
	if (plotSelection >= scope.visiblePlots.size())
	    plotSelection = 0;
	// More buttons than plots - remove extra buttons
	for (int i = chanButtons.size()-1; i >= scope.visiblePlots.size(); i--) {
	    channelButtonsp.remove(chanButtons.get(i));
	    chanButtons.remove(i);
	}
	// Now go though all the channels, adding new buttons if necessary
	for (int i=0; i<scope.visiblePlots.size(); i++) {
	    if (i>=chanButtons.size()) {
		Button b = new Button();
		chanButtons.add(b);
		chanButtons.get(i).addClickHandler(new PlotClickHandler(i));
		b.addStyleName("chbut");
		if (CircuitElm.whiteColor == Color.white)
			b.addStyleName("chbut-black");
		    else
			b.addStyleName("chbut-white");
		channelButtonsp.add(b);
	    }
	    Button b = chanButtons.get(i);
	    b.setHTML(getChannelButtonLabel(i));
	    if (i==plotSelection)
		b.addStyleName("chsel");
	    else
		b.removeStyleName("chsel");
	}
    }
    
    class expandingLabel {
	HorizontalPanel p;
	Label l;
	Button b;
	Boolean expanded;
	
	expandingLabel(String s, Boolean ex) {
	    expanded = ex;
	    p = new HorizontalPanel();
	    b = new Button(ex?"-":"+");
	    b.addClickHandler(new ClickHandler() {
		public void onClick(ClickEvent event) {
		    expanded=!expanded;
		    b.setHTML(expanded?"-":"+");
		    updateUi();
		}
	    });
	    b.addStyleName("expand-but");
	    p.add(b);
	    l = new Label (s);
	    l.getElement().getStyle().setFontWeight(FontWeight.BOLD);
	    p.add(l);
	    p.setCellVerticalAlignment(l, HasVerticalAlignment.ALIGN_BOTTOM);
	}
	
    }

	public ScopePropertiesDialog ( CirSim asim, Scope s) {
		super();
		// We are going to try and keep the panel below the target height (defined to give some space)
		int allowedHeight = Window.getClientHeight()*4/5;
		boolean displayAll = allowedHeight > 600; // We can display everything as maximum height can be shown
		boolean displayScales = allowedHeight > 470; // We can display the scales and any one other section. So expand scales and collapse rest
		sim=asim;
		scope = s;
		Button okButton, applyButton2;
		fp=new FlowPanel();
		setWidget(fp);
		setText(Locale.LS("Scope Properties"));

// *************** VERTICAL SCALE ***********************************************************
		Grid vSLG = new Grid(1,1); // Stupid grid to force labels to align without diving deep in to table CSS
		vScaleLabel = new expandingLabel(Locale.LS("Vertical Scale"), displayScales);
		vSLG.setWidget(0,0,vScaleLabel.p);
		fp.add(vSLG);
		
				
		vModep = new HorizontalPanel();
		autoButton = new RadioButton("vMode", Locale.LS("Auto"));
		autoButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
	            public void onValueChange(ValueChangeEvent<Boolean> e) {
	        	scope.setManualScale(false, false);
	        	scope.setMaxScale(false);
	        	updateUi();
	            }
	        });
		maxButton = new RadioButton("vMode", Locale.LS("Auto (Max Scale)"));
		maxButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
	            public void onValueChange(ValueChangeEvent<Boolean> e) {
	        	scope.setManualScale(false, false);
	        	scope.setMaxScale(true);
	        	updateUi();
	            }
	        });
		manualButton = new RadioButton("vMode", Locale.LS("Manual"));
		manualButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
	            public void onValueChange(ValueChangeEvent<Boolean> e) {
	        	scope.setManualScale(true, true);
	        	updateUi();
	            }
	        });
		vModep.add(autoButton);
		vModep.add(maxButton);
		vModep.add(manualButton);
		fp.add(vModep);
		channelSettingsp = new VerticalPanel();
		channelButtonsp = new FlowPanel();
		updateChannelButtons();
		channelSettingsp.add(channelButtonsp);
		fp.add(channelSettingsp);
		
		vScaleGrid = new Grid(4,5);
		dcButton= new RadioButton("acdc", Locale.LS("DC Coupled"));
		dcButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
		    if (plotSelection<scope.visiblePlots.size())
			scope.visiblePlots.get(plotSelection).setAcCoupled(false);
		    updateUi();
		    }
		});
		vScaleGrid.setWidget(0, 0, dcButton);
		acButton= new RadioButton("acdc", Locale.LS("AC Coupled"));
		acButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
		    if (plotSelection<scope.visiblePlots.size())
			scope.visiblePlots.get(plotSelection).setAcCoupled(true);
		    updateUi();
		    }
		});
		vScaleGrid.setWidget(0, 1, acButton);
		
		positionLabel= new Label(Locale.LS("Position"));
		vScaleGrid.setWidget(1,0, positionLabel);
		vScaleGrid.getCellFormatter().setVerticalAlignment(0, 0, HasVerticalAlignment.ALIGN_MIDDLE);
		positionBar = new Scrollbar(Scrollbar.HORIZONTAL,0, 1, -Scope.V_POSITION_STEPS, Scope.V_POSITION_STEPS, new Command() {
		    public void execute() {
			positionBarChanged();
		    }
		});
		vScaleGrid.setWidget(1,1,positionBar);
		Button resetPosButton = new Button(Locale.LS("Reset Position"));
		resetPosButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
			    positionBar.setValue(0);
			    positionBarChanged();
			    updateUi();
			}
		});
		vScaleGrid.setWidget(1, 4, resetPosButton);

		manualScaleId = new Label();
		vScaleGrid.setWidget(2, 0, manualScaleId);
		Grid scaleBoxGrid=new Grid(1,3);
		scaleDownButton=new Button("&#9660;");
		scaleDownButton.addClickHandler(new downClickHandler());
		scaleBoxGrid.setWidget(0,0, scaleDownButton);
		manualScaleTextBox = new TextBox(); 
		manualScaleTextBox.addValueChangeHandler(new manualScaleTextHandler());
		manualScaleTextBox.addStyleName("scalebox");
		scaleBoxGrid.setWidget(0, 1, manualScaleTextBox);
		scaleUpButton=new Button("&#9650;");
		scaleUpButton.addClickHandler(new upClickHandler());
		scaleBoxGrid.setWidget(0,2,scaleUpButton);
		vScaleGrid.setWidget(2,1, scaleBoxGrid);
		manualScaleLabel = new Label("");
		vScaleGrid.setWidget(2,2, manualScaleLabel);
		vScaleGrid.setWidget(2,4, applyButton = new Button(Locale.LS("Apply")));
		divisionsLabel = new Label(Locale.LS("# of Divisions"));
		divisionsTextBox = new TextBox();
		divisionsTextBox.addValueChangeHandler(new manualScaleTextHandler());
		vScaleGrid.setWidget(3,0, divisionsLabel);
		vScaleGrid.setWidget(3,1, divisionsTextBox);
		applyButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				apply();
			}
		});
		Button applyButtonDiv;
		vScaleGrid.setWidget(3,4, applyButtonDiv = new Button(Locale.LS("Apply")));
		applyButtonDiv.addClickHandler(new ClickHandler() { public void onClick(ClickEvent event) { apply(); } });

		vScaleGrid.getCellFormatter().setVerticalAlignment(1, 1, HasVerticalAlignment.ALIGN_MIDDLE);
		fp.add(vScaleGrid);

		// *************** HORIZONTAL SCALE ***********************************************************

		
		hScaleGrid = new Grid(2,4);
		hScaleLabel = new expandingLabel(Locale.LS("Horizontal Scale"), displayScales);
		hScaleGrid.setWidget(0, 0, hScaleLabel.p);
		speedBar = new Scrollbar(Scrollbar.HORIZONTAL, 2, 1, 0, 11, new Command() {
		    public void execute() {
			scrollbarChanged();
		    }
		});
		hScaleGrid.setWidget(1,0, speedBar);
		scopeSpeedLabel = new Label("");
		scopeSpeedLabel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		hScaleGrid.setWidget(1, 1, scopeSpeedLabel);
		hScaleGrid.getCellFormatter().setVerticalAlignment(1, 1, HasVerticalAlignment.ALIGN_MIDDLE);

	//	speedGrid.getColumnFormatter().setWidth(0, "40%");
		fp.add(hScaleGrid);

		// *************** TRIGGER ***********************************************************

		triggerGrid = new Grid(4,4);
		triggerLabel = new expandingLabel(Locale.LS("Trigger"), false);
		triggerGrid.setWidget(0, 0, triggerLabel.p);

		trigModep = new HorizontalPanel();
		trigFreeRunButton = new RadioButton("trigMode", Locale.LS("Free Run"));
		trigFreeRunButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
			if (e.getValue()) {
			    scope.setTriggerMode(ScopeTrigger.TRIGGER_FREERUN);
			    updateUi();
			}
		    }
		});
		trigNormalButton = new RadioButton("trigMode", Locale.LS("Normal"));
		trigNormalButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
			if (e.getValue()) {
			    scope.setTriggerMode(ScopeTrigger.TRIGGER_NORMAL);
			    updateUi();
			}
		    }
		});
		trigAutoButton = new RadioButton("trigMode", Locale.LS("Auto"));
		trigAutoButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
			if (e.getValue()) {
			    scope.setTriggerMode(ScopeTrigger.TRIGGER_AUTO);
			    updateUi();
			}
		    }
		});
		trigModep.add(trigFreeRunButton);
		trigModep.add(trigNormalButton);
		trigModep.add(trigAutoButton);
		triggerGrid.setWidget(1, 0, trigModep);

		trigEdgep = new HorizontalPanel();
		trigRisingButton = new RadioButton("trigEdge", Locale.LS("Rising"));
		trigRisingButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
			if (e.getValue()) {
			    scope.trigger.edge = ScopeTrigger.TRIGGER_EDGE_RISING;
			    scope.resetGraph();
			}
		    }
		});
		trigFallingButton = new RadioButton("trigEdge", Locale.LS("Falling"));
		trigFallingButton.addValueChangeHandler(new ValueChangeHandler<Boolean>() {
		    public void onValueChange(ValueChangeEvent<Boolean> e) {
			if (e.getValue()) {
			    scope.trigger.edge = ScopeTrigger.TRIGGER_EDGE_FALLING;
			    scope.resetGraph();
			}
		    }
		});
		trigEdgep.add(new Label(Locale.LS("Edge") + ": "));
		trigEdgep.add(trigRisingButton);
		trigEdgep.add(trigFallingButton);
		triggerGrid.setWidget(2, 0, trigEdgep);

		HorizontalPanel trigLevelp = new HorizontalPanel();
		trigLevelp.add(new Label(Locale.LS("Level") + ": "));
		triggerLevelTextBox = new TextBox();
		triggerLevelTextBox.addStyleName("scalebox");
		trigLevelp.add(triggerLevelTextBox);
		Button trigApplyButton = new Button(Locale.LS("Apply"));
		trigApplyButton.addClickHandler(new ClickHandler() {
		    public void onClick(ClickEvent event) {
			applyTriggerLevel();
		    }
		});
		trigLevelp.add(trigApplyButton);
		triggerGrid.setWidget(3, 0, trigLevelp);

		fp.add(triggerGrid);

		// *************** XY PLOT SETTINGS (embedded in main grid later) ***************
		xySettingsGrid = new Grid(3, 4);
		xyPlotXBox = new ListBox();
		xyPlotXBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			int idx = getListBoxValue(xyPlotXBox);
			if (idx >= 0) scope.plot2d.plotX = idx;
			scope.resetGraph();
		    }
		});
		xyPlotYBox = new ListBox();
		xyPlotYBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			int idx = getListBoxValue(xyPlotYBox);
			if (idx >= 0) scope.plot2d.plotY = idx;
			scope.resetGraph();
		    }
		});
		xyBrightnessBox = new ListBox();
		xyBrightnessBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			scope.plot2d.plotBrightness = getListBoxValue(xyBrightnessBox);
			scope.resetGraph();
		    }
		});
		xyRedBox = new ListBox();
		xyRedBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			scope.plot2d.plotColorR = getListBoxValue(xyRedBox);
			scope.resetGraph();
		    }
		});
		xyGreenBox = new ListBox();
		xyGreenBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			scope.plot2d.plotColorG = getListBoxValue(xyGreenBox);
			scope.resetGraph();
		    }
		});
		xyBlueBox = new ListBox();
		xyBlueBox.addChangeHandler(new ChangeHandler() {
		    public void onChange(ChangeEvent e) {
			scope.plot2d.plotColorB = getListBoxValue(xyBlueBox);
			scope.resetGraph();
		    }
		});
		xySettingsGrid.setWidget(0, 0, new Label(Locale.LS("X Axis:")));
		xySettingsGrid.setWidget(0, 1, xyPlotXBox);
		xySettingsGrid.setWidget(0, 2, new Label(Locale.LS("Y Axis:")));
		xySettingsGrid.setWidget(0, 3, xyPlotYBox);
		xySettingsGrid.setWidget(1, 0, new Label(Locale.LS("Brightness:")));
		xySettingsGrid.setWidget(1, 1, xyBrightnessBox);
		xySettingsGrid.setWidget(1, 2, new Label(Locale.LS("Red:")));
		xySettingsGrid.setWidget(1, 3, xyRedBox);
		xySettingsGrid.setWidget(2, 0, new Label(Locale.LS("Green:")));
		xySettingsGrid.setWidget(2, 1, xyGreenBox);
		xySettingsGrid.setWidget(2, 2, new Label(Locale.LS("Blue:")));
		xySettingsGrid.setWidget(2, 3, xyBlueBox);

		// *************** PLOTS ***********************************************************
		
		CircuitElm elm = scope.getSingleElm();
		boolean transistor = elm != null && elm instanceof TransistorElm;
		boolean capacitor = elm != null && elm instanceof CapacitorElm;
		if (!transistor) {
		    grid = new Grid(capacitor ? 14 : 13, 3);
		    gridLabels = new labelledGridManager(grid);
		    gridLabels.addLabel(Locale.LS("Plots"), displayAll);
		    addItemToGrid(grid, voltageBox = new ScopeCheckBox(Locale.LS("Show Voltage"), "showvoltage"));
		    voltageBox.addValueChangeHandler(this); 
		    addItemToGrid(grid, currentBox = new ScopeCheckBox(Locale.LS("Show Current"), "showcurrent"));
		    currentBox.addValueChangeHandler(this);
		} else {
		    grid = new Grid(15,3);
		    gridLabels = new labelledGridManager(grid);
		    gridLabels.addLabel(Locale.LS("Plots"), displayAll);
		    addItemToGrid(grid, ibBox = new ScopeCheckBox(Locale.LS("Show Ib"), "showib"));
		    ibBox.addValueChangeHandler(this);
		    addItemToGrid(grid, icBox = new ScopeCheckBox(Locale.LS("Show Ic"), "showic"));
		    icBox.addValueChangeHandler(this);
		    addItemToGrid(grid, ieBox = new ScopeCheckBox(Locale.LS("Show Ie"), "showie"));
		    ieBox.addValueChangeHandler(this);
		    addItemToGrid(grid, vbeBox = new ScopeCheckBox(Locale.LS("Show Vbe"), "showvbe"));
		    vbeBox.addValueChangeHandler(this);
		    addItemToGrid(grid, vbcBox = new ScopeCheckBox(Locale.LS("Show Vbc"), "showvbc"));
		    vbcBox.addValueChangeHandler(this);
		    addItemToGrid(grid, vceBox = new ScopeCheckBox(Locale.LS("Show Vce"), "showvce"));
		    vceBox.addValueChangeHandler(this);
		}
		addItemToGrid(grid, powerBox = new ScopeCheckBox(Locale.LS("Show Power Consumed"), "showpower"));
		powerBox.addValueChangeHandler(this);
		if (capacitor) {
		    addItemToGrid(grid, chargeBox = new ScopeCheckBox(Locale.LS("Show Charge"), "showcharge"));
		    chargeBox.addValueChangeHandler(this);
		}
		addItemToGrid(grid, resistanceBox = new ScopeCheckBox(Locale.LS("Show Resistance"), "showresistance"));
		resistanceBox.addValueChangeHandler(this);
		addItemToGrid(grid, spectrumBox = new ScopeCheckBox(Locale.LS("Show Spectrum"), "showfft"));
		spectrumBox.addValueChangeHandler(this);
		addItemToGrid(grid, logSpectrumBox = new ScopeCheckBox(Locale.LS("Log Spectrum"), "logspectrum"));
		logSpectrumBox.addValueChangeHandler(this);
		
		gridLabels.addLabel(Locale.LS("X-Y Plots"), displayAll);
		xyPlotsLabel = gridLabels.labels.lastElement();
		addItemToGrid(grid, viBox = new ScopeCheckBox(Locale.LS("Show V vs I"), "showvvsi"));
		viBox.addValueChangeHandler(this);
		addItemToGrid(grid, xyBox = new ScopeCheckBox(Locale.LS("Plot X/Y"), "plotxy"));
		xyBox.addValueChangeHandler(this);
		Grid trailGrid = new Grid(1, 3);
		trailGrid.setWidget(0, 0, new Label(Locale.LS("Trail Persistence (time steps)")));
		// Logarithmic: slider 0 = old default; slider n -> round(10^(n/10)) timesteps
		trailBar = new Scrollbar(Scrollbar.HORIZONTAL, trailStepsToSlider(scope.plot2d.trailPersistence), 1, 0, 61, new Command() {
		    public void execute() {
			scope.plot2d.trailPersistence = trailSliderToSteps(trailBar.getValue());
			setTrailLabel();
		    }
		});
		trailGrid.setWidget(0, 1, trailBar);
		trailLabel = new Label("");
		trailGrid.setWidget(0, 2, trailLabel);
		fp.add(trailGrid);
		setTrailLabel();
		if (transistor) {
		    addItemToGrid(grid, vceIcBox = new ScopeCheckBox(Locale.LS("Show Vce vs Ic"), "showvcevsic"));
		    vceIcBox.addValueChangeHandler(this);
		}
		// Embed XY settings grid inside the X-Y Plots section
		if (nx != 0) { nx = 0; ny++; }
		grid.setWidget(ny, 0, xySettingsGrid);
		xySettingsRow = ny;
		ny++;
		gridLabels.addLabel(Locale.LS("Show Info"), displayAll);
		addItemToGrid(grid, scaleBox = new ScopeCheckBox(Locale.LS("Show Scale"), "showscale"));
		scaleBox.addValueChangeHandler(this); 
		addItemToGrid(grid, peakBox = new ScopeCheckBox(Locale.LS("Show Peak Value"), "showpeak"));
		peakBox.addValueChangeHandler(this); 
		addItemToGrid(grid, negPeakBox = new ScopeCheckBox(Locale.LS("Show Negative Peak Value"), "shownegpeak"));
		negPeakBox.addValueChangeHandler(this);
		addItemToGrid(grid, p2pBox = new ScopeCheckBox(Locale.LS("Show Peak-to-Peak"), "showp2p"));
		p2pBox.addValueChangeHandler(this);
		addItemToGrid(grid, freqBox = new ScopeCheckBox(Locale.LS("Show Frequency"), "showfreq"));
		freqBox.addValueChangeHandler(this); 
		addItemToGrid(grid, averageBox = new ScopeCheckBox(Locale.LS("Show Average"), "showaverage"));
		averageBox.addValueChangeHandler(this); 
		addItemToGrid(grid, rmsBox = new ScopeCheckBox(Locale.LS("Show RMS Average"), "showrms"));
		rmsBox.addValueChangeHandler(this); 
		addItemToGrid(grid, dutyBox = new ScopeCheckBox(Locale.LS("Show Duty Cycle"), "showduty"));
		dutyBox.addValueChangeHandler(this);
		addItemToGrid(grid, phaseAngleBox = new ScopeCheckBox(Locale.LS("Show Phase Angle"), "showphaseangle"));
		phaseAngleBox.addValueChangeHandler(this);
		addItemToGrid(grid, elmInfoBox = new ScopeCheckBox(Locale.LS("Show Extended Info"), "showelminfo"));
		elmInfoBox.addValueChangeHandler(this); 
		fp.add(grid);

		gridLabels.addLabel(Locale.LS("Custom Label"), displayAll);
		labelTextBox = new TextBox();
		addItemToGrid(grid, labelTextBox);
		String labelText = scope.getText();
		if (labelText != null)
		    labelTextBox.setText(labelText);
		addItemToGrid(grid, applyButton2= new Button(Locale.LS("Apply")));
		applyButton2.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				apply();
			}
		});
		
		updateUi();
		hp = new HorizontalPanel();
		hp.setWidth("100%");
		hp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_LEFT);
		hp.setStyleName("topSpace");
		fp.add(hp);
		hp.add(okButton = new Button(Locale.LS("OK")));
		okButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				closeDialog();
			}
		});

//		hp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);

		
		hp.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		Button saveAsDefaultButton;
		hp.add(saveAsDefaultButton = new Button(Locale.LS("Save as Default")));
		saveAsDefaultButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				scope.saveAsDefault();
			}
		});
		this.center();
		show();
	}

	class labelledGridManager {
	    Grid g;
	    Vector <expandingLabel> labels;
	    Vector <Integer> labelRows;
	    
	    labelledGridManager(Grid gIn) {
		g=gIn;
		labels = new Vector <expandingLabel>();
		labelRows = new Vector <Integer>();
	    }
	    
	    void addLabel(String s, boolean e) {
        	    if (nx != 0)
        		ny++;
        	    nx = 0;
        	    expandingLabel l = new expandingLabel(Locale.LS(s), e);
        	    g.setWidget(ny, nx, l.p);
        	    labels.add(l);
        	    labelRows.add(ny);
        	    ny++;
	    }
	    
	    void updateRowVisibility() {
		for (int i=0; i<labels.size(); i++) {
		    int end;
		    int start = labelRows.get(i);
		    if (i<labels.size()-1)
			end = labelRows.get(i+1);
		    else
			end = g.getRowCount();
		    for(int j=start+1; j<end; j++)
			g.getRowFormatter().setVisible(j, labels.get(i).expanded);
		}
	    }
	    
	}
	
	
	// Get integer value from a ListBox (stored as the item's value string).
	int getListBoxValue(ListBox lb) {
	    int sel = lb.getSelectedIndex();
	    if (sel < 0) return -1;
	    try { return Integer.parseInt(lb.getValue(sel)); }
	    catch (Exception e) { return -1; }
	}

	// Populate a ListBox with all current scope.plots; optionally prepend a "None" (-1) entry.
	// Preserves the currently selected value if still present.
	void populatePlotListBox(ListBox lb, int selectedIdx, boolean includeNone) {
	    lb.clear();
	    if (includeNone)
		lb.addItem(Locale.LS("None"), "-1");
	    for (int i = 0; i < scope.plots.size(); i++) {
		ScopePlot p = scope.plots.get(i);
		String name = (p.elm != null) ? p.elm.getScopeText(p.value) : ("Plot " + (i + 1));
		lb.addItem(name + " (" + Scope.getScaleUnitsText(p.units) + ")", String.valueOf(i));
	    }
	    for (int i = 0; i < lb.getItemCount(); i++) {
		if (Integer.parseInt(lb.getValue(i)) == selectedIdx) {
		    lb.setSelectedIndex(i);
		    return;
		}
	    }
	    lb.setSelectedIndex(0);
	}

	void updateXYSettingsUi() {
	    boolean xyActive = scope.plot2d.plotXY;
	    // Show the row only when plotXY is on AND the "X-Y Plots" section is expanded.
	    // This runs after gridLabels.updateRowVisibility() so it can override its result.
	    if (xySettingsRow >= 0 && xyPlotsLabel != null)
		grid.getRowFormatter().setVisible(xySettingsRow, xyActive && xyPlotsLabel.expanded);
	    if (!xyActive) return;
	    populatePlotListBox(xyPlotXBox,      scope.plot2d.plotX,          false);
	    populatePlotListBox(xyPlotYBox,      scope.plot2d.plotY,          false);
	    populatePlotListBox(xyBrightnessBox, scope.plot2d.plotBrightness, true);
	    populatePlotListBox(xyRedBox,        scope.plot2d.plotColorR,     true);
	    populatePlotListBox(xyGreenBox,      scope.plot2d.plotColorG,     true);
	    populatePlotListBox(xyBlueBox,       scope.plot2d.plotColorB,     true);
	}

	void setScopeSpeedLabel() {
	    scopeSpeedLabel.setText(CircuitElm.getUnitText(scope.calcGridStepX(), "s")+"/div");
	}

	// Logarithmic mapping: slider 0 = old default (0 steps); slider n -> round(10^(n/10))
	static int trailSliderToSteps(int v) {
	    if (v <= 0) return 0;
	    return (int) Math.round(Math.pow(10, v / 10.0));
	}
	static int trailStepsToSlider(int steps) {
	    if (steps <= 0) return 0;
	    return (int) Math.round(Math.log10(steps) * 10);
	}

	void setTrailLabel() {
	    if (scope.plot2d.trailPersistence <= 0)
		trailLabel.setText(Locale.LS("default"));
	    else
		trailLabel.setText(CircuitElm.getUnitText(scope.plot2d.trailPersistence * sim.sim.maxTimeStep, "s"));
	}

	void addItemToGrid(Grid g, FocusWidget scb) {
	    g.setWidget(ny, nx, scb);
	    if (++nx >= grid.getColumnCount()) {
		nx = 0;
		ny++;
	    }
	}
	
	
	void scrollbarChanged() {
	    int newsp = (int)Math.pow(2,  10-speedBar.getValue());
	    CirSim.console("changed " + scope.speed + " " + newsp + " " + speedBar.getValue());
	    if (scope.speed != newsp)
		scope.setSpeed(newsp);
	    setScopeSpeedLabel();
	}
	
	void updateUi() {
	    vModep.setVisible(vScaleLabel.expanded);
	    gridLabels.updateRowVisibility();
	    hScaleGrid.getRowFormatter().setVisible(1, hScaleLabel.expanded);
	    speedBar.setValue(10-(int)Math.round(Math.log(scope.speed)/Math.log(2)));
	    if (voltageBox != null) {
		voltageBox.setValue(scope.showV && scope.hasPlotValue(Scope.VAL_VOLTAGE));
		currentBox.setValue(scope.showI && scope.hasPlotValue(Scope.VAL_CURRENT));
	    }
	    powerBox.setValue(scope.hasPlotValue(Scope.VAL_POWER));
	    scaleBox.setValue(scope.showScale);
	    peakBox.setValue(scope.showMax);
	    negPeakBox.setValue(scope.showMin);
	    p2pBox.setValue(scope.showP2P);
	    freqBox.setValue(scope.showFreq);
	    spectrumBox.setValue(scope.fftPlot.enabled);
	    logSpectrumBox.setValue(scope.fftPlot.logSpectrum);
	    rmsBox.setValue(scope.showRMS);
	    averageBox.setValue(scope.showAverage);
	    dutyBox.setValue(scope.showDutyCycle);
	    phaseAngleBox.setValue(scope.fftPlot.showPhaseAngle);
	    elmInfoBox.setValue(scope.showElmInfo);
	    rmsBox.setEnabled(scope.canShowRMS());
	    viBox.setValue(scope.plot2d.enabled && !scope.plot2d.plotXY);
	    xyBox.setValue(scope.plot2d.plotXY);
	    resistanceBox.setValue(scope.hasPlotValue(Scope.VAL_R));
	    resistanceBox.setEnabled(scope.canShowResistance());
	    if (chargeBox != null)
		chargeBox.setValue(scope.hasPlotValue(Scope.VAL_CHARGE));
	    if (vbeBox != null) {
                ibBox.setValue(scope.hasPlotValue(Scope.VAL_IB));
                icBox.setValue(scope.hasPlotValue(Scope.VAL_IC));
                ieBox.setValue(scope.hasPlotValue(Scope.VAL_IE));
                vbeBox.setValue(scope.hasPlotValue(Scope.VAL_VBE));
                vbcBox.setValue(scope.hasPlotValue(Scope.VAL_VBC));
                vceBox.setValue(scope.hasPlotValue(Scope.VAL_VCE));
                vceIcBox.setValue(scope.isShowingVceAndIc());
	    }
	    if (scope.isManualScale()) {
		manualButton.setValue(true);
		autoButton.setValue(false);
		maxButton.setValue(false);
		applyButton.setVisible(true);
	    }
	    else {
		manualButton.setValue(false);
		autoButton.setValue(! scope.maxScale);
		maxButton.setValue(scope.maxScale);
		applyButton.setVisible(false);
	    }
	    updateManualScaleUi();
	    
	    

	    // Trigger section
	    trigFreeRunButton.setValue(scope.trigger.mode == ScopeTrigger.TRIGGER_FREERUN);
	    trigNormalButton.setValue(scope.trigger.mode == ScopeTrigger.TRIGGER_NORMAL);
	    trigAutoButton.setValue(scope.trigger.mode == ScopeTrigger.TRIGGER_AUTO);
	    boolean trigActive = scope.trigger.isActive();
	    trigRisingButton.setValue(scope.trigger.edge == ScopeTrigger.TRIGGER_EDGE_RISING);
	    trigFallingButton.setValue(scope.trigger.edge == ScopeTrigger.TRIGGER_EDGE_FALLING);
	    trigRisingButton.setEnabled(trigActive);
	    trigFallingButton.setEnabled(trigActive);
	    triggerLevelTextBox.setText(EditDialog.unitString(null, scope.trigger.level));
	    triggerLevelTextBox.setEnabled(trigActive);
	    // Show/hide trigger details based on section expansion
	    trigModep.setVisible(triggerLabel.expanded);
	    trigEdgep.setVisible(triggerLabel.expanded && trigActive);
	    triggerGrid.getRowFormatter().setVisible(1, triggerLabel.expanded);
	    triggerGrid.getRowFormatter().setVisible(2, triggerLabel.expanded && trigActive);
	    triggerGrid.getRowFormatter().setVisible(3, triggerLabel.expanded && trigActive);

	    updateXYSettingsUi();
	    // if you add more here, make sure it still works with transistor scopes
	}
	
	void updateManualScaleUi() {
	    updateChannelButtons();
	    channelSettingsp.setVisible(scope.isManualScale() && vScaleLabel.expanded);
	    vScaleGrid.setVisible(vScaleLabel.expanded);
	    if (vScaleLabel.expanded) { 
        	    vScaleGrid.getRowFormatter().setVisible(0, scope.isManualScale() && plotSelection<scope.visiblePlots.size() );
        	    vScaleGrid.getRowFormatter().setVisible(1, scope.isManualScale() && plotSelection<scope.visiblePlots.size() );
        	    vScaleGrid.getRowFormatter().setVisible(2, (!scope.isManualScale()) || plotSelection<scope.visiblePlots.size());
        	    vScaleGrid.getRowFormatter().setVisible(3, scope.isManualScale());
	    }
	    scaleUpButton.setVisible(scope.isManualScale());
	    scaleDownButton.setVisible(scope.isManualScale());
	    if (scope.isManualScale()) {
		if (plotSelection<scope.visiblePlots.size()) {
		    ScopePlot p = scope.visiblePlots.get(plotSelection);
		    manualScaleId.setText("CH "+String.valueOf(plotSelection+1)+" "+Locale.LS("Scale"));
		    manualScaleLabel.setText(Scope.getScaleUnitsText(p.units)+Locale.LS("/div"));
		    manualScaleTextBox.setText(EditDialog.unitString(null, p.manScale));
		    manualScaleTextBox.setEnabled(true);
		    divisionsTextBox.setText(String.valueOf(scope.manDivisions));
		    divisionsTextBox.setEnabled(true);
		    positionLabel.setText("CH "+String.valueOf(plotSelection+1)+" "+Locale.LS("Position"));
		    positionBar.setValue(p.manVPosition);
		    dcButton.setEnabled(true);
		    positionBar.enable();
		    dcButton.setValue(! p.isAcCoupled());
		    acButton.setEnabled(p.canAcCouple());
		    acButton.setValue(p.isAcCoupled());
		    
		} else {
		    manualScaleId.setText("");
		    manualScaleLabel.setText("");
		    manualScaleTextBox.setText("");
		    manualScaleTextBox.setEnabled(false);
		    positionLabel.setText("");
		    dcButton.setEnabled(false);
		    acButton.setEnabled(false);
		    positionBar.disable();
		    
		}
	    } else {
		manualScaleId.setText("");
		manualScaleLabel.setText(Locale.LS("Max Value") + " (" + scope.getScaleUnitsText() + ")");
		manualScaleTextBox.setText(EditDialog.unitString(null, scope.getScaleValue()));
		manualScaleTextBox.setEnabled(false);
		positionLabel.setText("");
	    }
	    setScopeSpeedLabel();
	}
	
	void refreshDraw() {
	    // Redraw for every step of the simulation (the simulation may run in the background of this
	    // dialog and the scope may automatically rescale
	    if (! scope.isManualScale() )
		updateManualScaleUi();
	}
	
	public void closeDialog()
	{
	    super.closeDialog();
	    apply();
	}
	
	double getManualScaleValue()
	{
	    try {
		double d = EditDialog.parseUnits(manualScaleTextBox.getText());
		if (d< Scope.MIN_MAN_SCALE)
		    d= Scope.MIN_MAN_SCALE;
		return d;
	    } catch (Exception e) {
		return 0;
	    }
	}
	
	int getDivisionsValue()
	{
	    try {
		int n = Integer.parseInt(divisionsTextBox.getText());
		return n;
	    } catch (Exception e) {
		return 0;
	    }
	}
	
	boolean apply() {
	    String label = labelTextBox.getText();
	    if (label.length() == 0)
		label = null;
	    scope.setText(label);

	    if (scope.isManualScale()) {
		double d=getManualScaleValue();
		if (d>0)
		    scope.setManualScaleValue(plotSelection, d);
		int n = getDivisionsValue();
		if (n > 0)
		    scope.setManDivisions(n);
	    }
	    return true;
	}

	void applyTriggerLevel() {
	    try {
		double d = EditDialog.parseUnits(triggerLevelTextBox.getText());
		scope.trigger.level = d;
		scope.resetGraph();
	    } catch (Exception e) {
	    }
	}

	public void onValueChange(ValueChangeEvent<Boolean> event) {
	    ScopeCheckBox cb = (ScopeCheckBox) event.getSource();
	    scope.handleMenu(cb.menuCmd, cb.getValue());
	    updateUi();
	}


}
