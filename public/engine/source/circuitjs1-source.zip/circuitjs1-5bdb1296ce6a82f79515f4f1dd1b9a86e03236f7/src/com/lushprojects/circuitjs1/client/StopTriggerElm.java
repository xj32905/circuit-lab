/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.lushprojects.circuitjs1.client.util.Locale;

class StopTriggerElm extends CircuitElm {
	double triggerVoltage;
	boolean triggered, stopped, conditionActive, durationMet;
	double delay, triggerTime;
	double requiredDuration, conditionStartTime;
	int type;
	int count;
	int triggerCount;

	public StopTriggerElm(int xx, int yy) {
	    super(xx, yy);
	    triggerVoltage = 1;
	    count = 1;
	}
	public StopTriggerElm(int xa, int ya, int xb, int yb, int f,
			 StringTokenizer st) {
	    super(xa, ya, xb, yb, f);
	    triggerVoltage = Double.parseDouble(st.nextToken());
	    type = Integer.parseInt(st.nextToken());
	    delay = Double.parseDouble(st.nextToken());
	    count = 1;
	}
	void dumpXml(Document doc, Element elem) {
	    super.dumpXml(doc, elem);
	    XMLSerializer.dumpAttr(elem, "tv", triggerVoltage);
	    XMLSerializer.dumpAttr(elem, "tp", type);
	    XMLSerializer.dumpAttr(elem, "dl", delay);
	    XMLSerializer.dumpAttr(elem, "ct", count);
	    XMLSerializer.dumpAttr(elem, "rd", requiredDuration);
	}
	void undumpXml(XMLDeserializer xml) {
	    super.undumpXml(xml);
	    triggerVoltage = xml.parseDoubleAttr("tv", triggerVoltage);
	    type = xml.parseIntAttr("tp", type);
	    delay = xml.parseDoubleAttr("dl", delay);
	    count = xml.parseIntAttr("ct", 1);
	    if (count < 1)
		count = 1;
	    requiredDuration = xml.parseDoubleAttr("rd", 0);
	}
	void reset() {
	    triggered = false;
	    conditionActive = false;
	    durationMet = false;
	    triggerCount = 0;
	}
	int getDumpType() { return 408; }
	int getPostCount() { return 1; }
	void setPoints() {
	    super.setPoints();
	    lead1 = interpPoint(point1, point2, 1-8/dn);
	}
		
	void draw(Graphics g) {
	    g.save();
	    boolean selected = needsHighlight() || stopped;
	    Font f = new Font("SansSerif", selected ? Font.BOLD : 0, 14);
	    g.setFont(f);
	    g.setColor(selected ? selectColor : whiteColor);
	    setBbox(point1, lead1, 0);
	    String s = Locale.LS("trigger");
	    drawLabeledNode(g, s, point1, lead1);
	    setVoltageColor(g, volts[0]);
	    if (selected)
		g.setColor(selectColor);
	    drawThickLine(g, point1, lead1);
	    drawPosts(g);
	    g.restore();
	}
	void stepFinished() {
	    stopped = false;
	    boolean condition = (type == 0 && volts[0] >= triggerVoltage) || (type == 1 && volts[0] <= triggerVoltage);
	    if (!conditionActive && condition) {
		conditionActive = true;
		conditionStartTime = sim.t;
		durationMet = false;
	    }
	    if (conditionActive && condition && !durationMet && sim.t-conditionStartTime >= requiredDuration) {
		durationMet = true;
		triggerCount++;
		if (!triggered && triggerCount >= count) {
		    triggered = true;
		    triggerTime = sim.t;
		}
	    }
	    if (conditionActive && !condition)
		conditionActive = false;
	    if (triggered && sim.t >= triggerTime+delay) {
		triggered = false;
		triggerCount = 0;
		stopped = true;
		app.setSimRunning(false);
	    }
	}
	
	double getVoltageDiff() { return volts[0]; }
	void getInfo(String arr[]) {
	    arr[0] = "stop trigger";
	    arr[1] = "V = " + getVoltageText(volts[0]);
	    arr[2] = "Vtrigger = " + getVoltageText(triggerVoltage);
	    arr[3] = (triggered) ? ("stopping in " + getUnitText(triggerTime+delay-sim.t, "s")) : (stopped) ? "stopped" : "waiting";
	    if (!stopped && count > 1)
		arr[3] += " (" + Math.min(triggerCount, count) + "/" + count + ")";
	}
	public EditInfo getEditInfo(int n) {
	    if (n == 0) {
		EditInfo ei = new EditInfo("Voltage", triggerVoltage);
		return ei.setUnitStep();
	    }
	    if (n == 1) {
		EditInfo ei =  new EditInfo("Trigger Type", type, -1, -1);
		ei.choice = new Choice();
		ei.choice.add(">=");
		ei.choice.add("<=");
		ei.choice.select(type);
		return ei;
	    }
	    if (n == 2) {
		EditInfo ei = new EditInfo("Delay (s)", delay);
		return ei;
	    }
	    if (n == 3) {
		EditInfo ei = new EditInfo("Required Duration (s)", requiredDuration);
		return ei;
	    }
	    if (n == 4) {
		EditInfo ei = new EditInfo("Required Count", count, -1, -1);
		return ei.setDimensionless().setPositive();
	    }
	    return null;
	}
	public void setEditValue(int n, EditInfo ei) {
	    if (n == 0)
		triggerVoltage = ei.value;
	    if (n == 1)
		type = ei.choice.getSelectedIndex();
	    if (n == 2)
		delay = ei.value;
	    if (n == 3) {
		requiredDuration = ei.value;
		if (requiredDuration < 0)
		    requiredDuration = 0;
	    }
	    if (n == 4) {
		count = (int) ei.value;
		if (count < 1)
		    count = 1;
	    }
	}
    }
