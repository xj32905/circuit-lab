/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

    import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Document;

class LogicInputElm extends SwitchElm {
	final int FLAG_TERNARY = 1;
	final int FLAG_NUMERIC = 2;
	double hiV, loV;
	public LogicInputElm(int xx, int yy) {
	    super(xx, yy, false);
	    hiV = 5;
	    loV = 0;
	    
	}
	public LogicInputElm(int xa, int ya, int xb, int yb, int f,
			     StringTokenizer st) {
	    super(xa, ya, xb, yb, f, st);
	    try {
		hiV = new Double(st.nextToken()).doubleValue();
		loV = new Double(st.nextToken()).doubleValue();
	    } catch (Exception e) {
		hiV = 5;
		loV = 0;
	    }
	    if (isTernary())
		posCount = 3;
	}
	boolean isTernary() { return (flags & FLAG_TERNARY) != 0; }
	boolean isNumeric() { return (flags & (FLAG_TERNARY|FLAG_NUMERIC)) != 0; }
	int getDumpType() { return 'L'; }
	String dump() {
	    return super.dump() + " " + hiV + " " + loV;
	}

	void dumpXml(Document doc, Element elem) {
	    super.dumpXml(doc, elem);
	    if (hiV != 5)
		XMLSerializer.dumpAttr(elem, "hi", hiV);
	    if (loV != 0)
		XMLSerializer.dumpAttr(elem, "lo", loV);
	}

	void undumpXml(XMLDeserializer xml) {
	    super.undumpXml(xml);
	    hiV = xml.parseDoubleAttr("hi", hiV);
	    loV = xml.parseDoubleAttr("lo", loV);
	}

	int getPostCount() { return 1; }
	void setPoints() {
	    super.setPoints();
	    lead1 = interpPoint(point1, point2, 1-12/dn);
	}
	void draw(Graphics g) {
	    g.save();
	    Font f = new Font("SansSerif", Font.BOLD, 20);
	    g.setFont(f);
	    g.setColor(needsHighlight() ? selectColor : whiteColor);
	    String s = position == 0 ? "L" : "H";
	    if (isNumeric())
		s = "" + position;
	    setBbox(point1, lead1, 0);
	    drawCenteredText(g, s, x2, y2, true);
	    setVoltageColor(g, volts[0]);
	    drawThickLine(g, point1, lead1);
	    updateDotCount();
	    drawDots(g, point1, lead1, -curcount);
	    drawPosts(g);
	    g.restore();
	}
	
	Rectangle getSwitchRect() {
	    return new Rectangle(x2-10, y2-10, 20, 20);
	}	

	void setCurrent(VoltageSource vs, double c) { current = c; }
	void calculateCurrent() {}
	void stamp() {
	    sim.stampVoltageSource(CircuitNode.ground, nodes[0], voltSource);
	}
	
	boolean isWireEquivalent() { return false; }
	boolean isRemovableWire() { return false; }

	void doStep() {
	    double v = (position == 0) ? loV : hiV;
	    if (isTernary())
		v = loV + position * (hiV-loV) * .5;
	    sim.updateVoltageSource(CircuitNode.ground, nodes[0], voltSource, v);
	}
	int getVoltageSourceCount() { return 1; }
	double getVoltageDiff() { return volts[0]; }
	String getElmType() { return "logic input"; }
	void getInfo(String arr[]) {
	    arr[0] = "logic input";
	    arr[1] = (position == 0) ? "low" : "high";
	    if (isNumeric())
		arr[1] = "" + position;
	    arr[1] += " (" + getVoltageText(volts[0]) + ")";
	    arr[2] = "I = " + getCurrentText(getCurrent());
	} 
	boolean hasGroundConnection(int n1) { return true; }
	public EditInfo getEditInfo(int n) {
	    if (n == 0) {
		EditInfo ei = new EditInfo("", 0, 0, 0);
		ei.checkbox = new Checkbox("Momentary Switch", momentary);
		return ei;
	    }
	    if (n == 1)
		return new EditInfo("High Logic Voltage", hiV, 10, -10).setUnitStep();
	    if (n == 2)
		return new EditInfo("Low Voltage", loV, 10, -10).setUnitStep();
	    if (n == 3) {
		EditInfo ei = new EditInfo("", 0, 0, 0);
		ei.checkbox = new Checkbox("Numeric", isNumeric());
		return ei;
	    }
	    if (n == 4) {
		EditInfo ei = new EditInfo("", 0, 0, 0);
		ei.checkbox = new Checkbox("Ternary", isTernary());
		return ei;
	    }
	    if (n == 5)
		return getKeyShortcutEditInfo();
	    return null;
	}
	public void setEditValue(int n, EditInfo ei) {
	    if (n == 0)
		momentary = ei.checkbox.getState();
	    if (n == 1)
		hiV = ei.value;
	    if (n == 2)
		loV = ei.value;
	    if (n == 3) {
		if (ei.checkbox.getState())
		    flags |= FLAG_NUMERIC;
		else
		    flags &= ~FLAG_NUMERIC;
	    }
	    if (n == 4) {
		if (ei.checkbox.getState())
		    flags |= FLAG_TERNARY;
		else
		    flags &= ~FLAG_TERNARY;
		posCount = (isTernary()) ? 3 : 2;
	    }
	    if (n == 5)
		setKeyShortcutEditValue(ei);
	}
	void addRoutingObstacle(WireRouter router) {
	    router.addWire(point1.x, point1.y, lead1.x, lead1.y);
	    router.addObstacle(x2 - 10, y2 - 10, x2 + 10, y2 + 10);
	}

	int getShortcut() { return 'i'; }
	
	double getCurrentIntoNode(int n) {
	    return current;
	}
	boolean validate() { return validateRailNode(0); }
    }
