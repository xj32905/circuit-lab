/*    
    Copyright (C) Paul Falstad and Iain Sharp
    
    This file is part of CircuitJS1.

    CircuitJS1 is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 2 of the License, or
    (at your option) any later version.

    CircuitJS1 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
*/

package com.lushprojects.circuitjs1.client;

import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.Document;

import com.lushprojects.circuitjs1.client.util.Locale;

class OutputElm extends CircuitElm {
	final int FLAG_VALUE = 1;
	final int FLAG_FIXED = 2;
        int scale;
	public OutputElm(int xx, int yy) {
	    super(xx, yy);
	    scale = SCALE_AUTO;
	}
	public OutputElm(int xa, int ya, int xb, int yb, int f,
			 StringTokenizer st) {
	    super(xa, ya, xb, yb, f);
	    scale = SCALE_AUTO;
	    try {
		scale = Integer.parseInt(st.nextToken());
	    } catch (Exception e) {}
	}
	
	void dumpXml(Document doc, Element elem) {
	    super.dumpXml(doc, elem);
	    XMLSerializer.dumpAttr(elem, "sc", scale);
	}

	void undumpXml(XMLDeserializer xml) {
	    super.undumpXml(xml);
	    scale = xml.parseIntAttr("sc", scale);
	}

	int getDumpType() { return 'O'; }
	int getPostCount() { return 1; }
	void setPoints() {
	    super.setPoints();
	    lead1 = new Point();
	}
	void draw(Graphics g) {
	    g.save();
	    boolean selected = needsHighlight();
	    Font f = new Font("SansSerif", selected ? Font.BOLD : 0, 14);
	    g.setFont(f);
	    g.setColor(selected ? selectColor : lightGrayColor);
	    String s = showVoltage() ? getUnitTextWithScale(volts[0], "V", scale, isFixed()) : Locale.LS("out");
//	    FontMetrics fm = g.getFontMetrics();
	    String role = app.mouse.scopePlotRoles.get(this);
	    if (role != null && !role.isEmpty())
		s = role;
	    interpPoint(point1, point2, lead1, 1-((int)g.context.measureText(s).getWidth()/2+8)/dn);
	    setBbox(point1, lead1, 0);
	    drawCenteredText(g, s, x2, y2, true);
	    setVoltageColor(g, volts[0]);
	    if (selected)
		g.setColor(selectColor);
	    drawThickLine(g, point1, lead1);
	    drawPosts(g);
	    g.restore();
	}
	void addRoutingObstacle(WireRouter router) {
	    router.addWire(point1.x, point1.y, x2, y2);
	    router.addObstacle(x2 - 10, y2 - 10, x2 + 10, y2 + 10);
	}

	double getVoltageDiff() { return volts[0]; }
	void getInfo(String arr[]) {
	    arr[0] = "output";
	    arr[1] = "V = " + getVoltageText(volts[0]);
	}
	public EditInfo getEditInfo(int n) {
	    if (n == 0)
		return EditInfo.createCheckbox("Show Voltage", showVoltage());
	    if (!showVoltage())
		return null;
	    if (n == 1) {
		EditInfo ei =  new EditInfo("Scale", 0);
		ei.choice = new Choice();
		ei.choice.add("Auto");
		ei.choice.add("V");
		ei.choice.add("mV");
		ei.choice.add(Locale.muString + "V");
		ei.choice.select(scale);
		return ei;
	    }
	    if (scale == SCALE_AUTO)
		return null;
	    if (n == 2)
		return EditInfo.createCheckbox("Fixed Precision", isFixed());
	    return null;
	}
	boolean isFixed() { return (flags & FLAG_FIXED) != 0; }
	boolean showVoltage() { return (flags & FLAG_VALUE) != 0; }
	public void setEditValue(int n, EditInfo ei) {
	    if (n == 0) {
		flags = ei.changeFlag(flags, FLAG_VALUE);
		ei.newDialog = true;
	    }
	    if (n==1) {
		scale = ei.choice.getSelectedIndex();
		ei.newDialog = true;
	    }
	    if (n == 2)
		flags = ei.changeFlag(flags, FLAG_FIXED);
	}

//    void drawHandles(Graphics g, Color c) {
//    	g.setColor(c);
//		g.fillRect(x-3, y-3, 7, 7);
//    }
    
    }
